import { ChangeDetectionStrategy, Component, computed, inject, signal, ViewChild, ElementRef, effect, OnDestroy, OnInit, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService, EvaluationResult } from '../../services/gemini.service';
import { InterviewService } from '../../services/interview.service';
import { AuthService } from '../../services/auth.service';
import { HeaderComponent } from '../shared/header.component';

type InterviewState = 'not-started' | 'permission-check' | 'camera-check' | 'get-ready' | 'in-progress' | 'evaluating' | 'feedback' | 'completed' | 'error';
type PermissionState = 'prompt' | 'granted' | 'denied';
type RecordingStatus = 'idle' | 'recording' | 'paused';


// This is needed for the SpeechRecognition API typings
declare var webkitSpeechRecognition: any;

@Component({
  selector: 'app-interview',
  standalone: true,
  templateUrl: './interview.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, HeaderComponent]
})
export class InterviewComponent implements OnDestroy, OnInit {
  geminiService = inject(GeminiService);
  interviewService = inject(InterviewService);
  authService = inject(AuthService);

  @Output() interviewComplete = new EventEmitter<string>();
  sessionId = signal<string | null>(null);

  @ViewChild('videoPreview', { static: false }) videoPreview!: ElementRef<HTMLVideoElement>;
  @ViewChild('audioVisualizerCanvas', { static: false }) audioVisualizerCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('qualityCheckCanvas', { static: false }) qualityCheckCanvas!: ElementRef<HTMLCanvasElement>;

  interviewState = signal<InterviewState>('not-started');
  currentYear = new Date().getFullYear();
  
  // --- Evaluation Progress State ---
  evaluationProgressSteps = signal<{text: string, status: 'in-progress' | 'done' | 'pending'}[]>([]);
  evaluationStatusMessage = signal('Initializing AI analysis...');
  private statusInterval: any;

  // --- Permission State ---
  cameraPermission = signal<PermissionState>('prompt');
  micPermission = signal<PermissionState>('prompt');
  
  // --- Recording State ---
  recordingStatus = signal<RecordingStatus>('idle');
  mediaRecorder: MediaRecorder | null = null;
  recordedBlob = signal<Blob | null>(null);
  recordedUrl = signal<string | null>(null);
  private recordedChunks: Blob[] = [];

  // --- Countdown Timer State ---
  readonly maxRecordingTime = 120; // Max duration in seconds (2 minutes)
  timeRemaining = signal(this.maxRecordingTime);
  private timerInterval: any;
  timesUp = signal(false);

  // --- Get Ready Countdown State ---
  getReadyCountdown = signal(3);
  private getReadyInterval: any;

  formattedTimeRemaining = computed(() => {
    const totalSeconds = this.timeRemaining();
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  });

  timerProgress = computed(() => {
    return ((this.maxRecordingTime - this.timeRemaining()) / this.maxRecordingTime) * 100;
  });

  // --- Video Specific State ---
  videoStream = signal<MediaStream | null>(null);
  facingMode = signal<'user' | 'environment'>('user');
  hasMultipleCameras = signal(false);
  isMicMuted = signal(false);

  // --- Audio Visualization State ---
  audioStream = signal<MediaStream | null>(null);
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private dataArray: Uint8Array | null = null;
  private animationFrameId: number | null = null;

  // --- Speech To Text State ---
  isListening = signal(false);
  private speechRecognition: any | null = null;
  finalTranscript = signal('');
  interimTranscript = signal('');
  userAnswer = computed(() => this.finalTranscript() + this.interimTranscript());

  // --- Quality Check State ---
  lightQuality = signal<'good' | 'low' | 'checking'>('checking');
  audioQuality = signal<'good' | 'low' | 'muted' | 'checking'>('checking');
  private qualityCheckInterval: any;

  private questions = computed(() => this.interviewService.getActiveQuestions());

  currentQuestionIndex = signal(0);
  currentQuestion = computed(() => this.questions()[this.currentQuestionIndex()]);
  
  // --- Feedback State ---
  lastEvaluationResult = signal<EvaluationResult | null>(null);
  
  progress = computed(() => {
    const totalQuestions = this.questions().length;
    if (totalQuestions === 0) {
      return 0;
    }
    // Progress should reflect being "on" the current question, so we use +1
    return ((this.currentQuestionIndex() + 1) / totalQuestions) * 100;
  });

  errorMessage = this.geminiService.error;

  showErrorDetails = signal(false);

  errorDetails = computed(() => {
    const msg = this.errorMessage();
    if (!msg) {
        return { reason: 'An unknown error occurred.', suggestion: 'Please try again or restart the interview.', icon: 'unknown' };
    }
    const lowerMsg = msg.toLowerCase();

    // Media Device Errors
    if (lowerMsg.includes('permission') && lowerMsg.includes('denied') && lowerMsg.includes('microphone')) return { reason: 'Microphone Access Denied.', suggestion: 'Microphone access is required. Please enable it in your browser\'s site settings for this page and then reload.', icon: 'mic-denied' };
    if (lowerMsg.includes('permission') && lowerMsg.includes('denied')) return { reason: 'Media Access Denied.', suggestion: 'Camera and microphone access is required. Please enable it in your browser\'s site settings for this page and then reload.', icon: 'cam-denied' };
    if (lowerMsg.includes('not found')) return { reason: 'Device Not Found.', suggestion: 'No camera or microphone was detected. Please ensure your devices are properly connected and enabled in your system settings.', icon: 'cam-not-found' };
    if (lowerMsg.includes('in use')) return { reason: 'Device In Use.', suggestion: 'Your camera or microphone is being used by another application. Please close it and try again.', icon: 'cam-in-use' };
    if (lowerMsg.includes('specifications') || lowerMsg.includes('overconstrained')) return { reason: 'Unsupported Device.', suggestion: 'The selected camera does not meet the required specifications (e.g., resolution). Try another device if available.', icon: 'cam-unsupported' };
    if (lowerMsg.includes('insecure connection')) return { reason: 'Insecure Connection.', suggestion: 'Camera and microphone access requires a secure (HTTPS) connection. Please check the website URL.', icon: 'insecure' };

    // AI Service Errors
    if (lowerMsg.includes('api key')) return { reason: 'Configuration Error.', suggestion: 'The application is not configured correctly to communicate with the AI service. Please contact support.', icon: 'api-key' };
    if (lowerMsg.includes('network')) return { reason: 'Network Connection Error.', suggestion: 'A connection to the AI service could not be established. Please check your internet connection and retry the question.', icon: 'network' };
    if (lowerMsg.includes('busy')) return { reason: 'AI Service Overloaded.', suggestion: 'The AI service is currently experiencing high demand. Please wait a few moments before retrying your request.', icon: 'service-busy' };
    if (lowerMsg.includes('500') || lowerMsg.includes('503')) return { reason: 'AI Service Error.', suggestion: 'The AI service is experiencing technical problems. The issue has been logged. Please try again later.', icon: 'service-error' };
    if (lowerMsg.includes('invalid') || lowerMsg.includes('400') || lowerMsg.includes('too large') || lowerMsg.includes('corrupted') || lowerMsg.includes('unexpected format')) return { reason: 'Invalid Request.', suggestion: 'The AI couldn\'t process the request. This can happen if the video is too long, corrupted, or if the AI returned an unexpected response. Please try recording a shorter answer.', icon: 'invalid-request' };
    
    // Other Errors
    if (lowerMsg.includes('speech recognition')) return { reason: 'Speech Recognition Error.', suggestion: 'There was an issue with the speech-to-text service. Please check your microphone connection and browser permissions.', icon: 'speech-error' };
    
    return { reason: 'An Unexpected Error Occurred.', suggestion: 'Please try again. If the problem persists, try restarting the interview.', icon: 'unknown' };
  });

  canRetry = computed(() => !['api-key', 'cam-denied', 'mic-denied', 'cam-not-found', 'cam-unsupported', 'insecure'].includes(this.errorDetails().icon));

  constructor() {
    // Effect to attach video stream to the video element
    effect(() => {
      const stream = this.videoStream();
      if (this.videoPreview?.nativeElement) {
        this.videoPreview.nativeElement.srcObject = stream;
      }
    });

    // Effect for audio visualization to prevent race conditions
    effect(() => {
        const status = this.recordingStatus();
        // This effect runs when status changes or when audioVisualizerCanvas becomes available.
        if (status === 'recording' && this.audioVisualizerCanvas?.nativeElement) {
            this.setupAudioVisualization();
        } else {
            this.stopAudioVisualization();
        }
    });

    // Effect to safely manage Speech Recognition API based on recording status
    effect(() => {
      if (!this.speechRecognition) return;
      const status = this.recordingStatus();
      if (status === 'recording' && !this.isListening()) {
        this.speechRecognition.start();
      } else if ((status === 'paused' || status === 'idle') && this.isListening()) {
        this.speechRecognition.stop();
      }
    });
    
    // Effect to safely manage quality checks
    effect(() => {
      if (this.interviewState() === 'camera-check' && this.qualityCheckCanvas?.nativeElement) {
        this.startQualityChecks();
      } else {
        this.stopQualityChecks();
      }
    });
  }
  
  ngOnInit(): void {
    this.setupSpeechRecognition();
  }

  ngOnDestroy(): void {
    this.stopMediaStreams();
    if (this.speechRecognition) {
      this.speechRecognition.abort();
    }
    clearInterval(this.statusInterval);
    clearInterval(this.getReadyInterval);
    this.interviewService.exitFocusMode();
  }
  
  private setupSpeechRecognition(): void {
    if ('webkitSpeechRecognition' in window) {
      this.speechRecognition = new webkitSpeechRecognition();
      this.speechRecognition.continuous = true;
      this.speechRecognition.interimResults = true;
      
      this.speechRecognition.onstart = () => this.isListening.set(true);

      this.speechRecognition.onresult = (event: any) => {
        let final = '';
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        this.finalTranscript.update(val => val + final);
        this.interimTranscript.set(interim);
      };

      this.speechRecognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        if (event.error !== 'no-speech' && event.error !== 'aborted') {
            let errorMessage = `Speech recognition error: ${event.error}.`;
            if (event.error === 'network') {
                errorMessage = 'A network error occurred with the speech recognition service. Please check your connection.';
            } else if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
                errorMessage = 'Microphone access was denied for the speech recognition service.';
            } else if (event.error === 'audio-capture') {
                errorMessage = 'There was a problem with your microphone. Please check if it is working correctly.';
            }
            this.geminiService.error.set(errorMessage);
            this.interviewState.set('error');
        }
        this.isListening.set(false);
      };

      this.speechRecognition.onend = () => this.isListening.set(false);
    } else {
      console.warn('Speech Recognition not supported in this browser.');
    }
  }

  async startInterview(): Promise<void> {
    if (this.questions().length === 0) {
      this.geminiService.error.set("No interview questions available for this session.");
      this.interviewState.set('error');
      return;
    }
    this.sessionId.set(`session_${Date.now()}`);
    this.currentQuestionIndex.set(0);
    this.discardCurrentAnswer();
    this.geminiService.error.set(null);
    this.showErrorDetails.set(false);
    
    this.interviewState.set('permission-check');
  }
  
  async requestPermissions(): Promise<void> {
    this.interviewState.set('camera-check');
    const stream = await this.initializeVideoStream(true);
    if (!stream) {
      this.interviewState.set('error');
    }
  }

  confirmCameraReady(): void {
    this.stopQualityChecks();
    this.interviewState.set('get-ready');
    this.getReadyCountdown.set(3);
    this.getReadyInterval = setInterval(() => {
        this.getReadyCountdown.update(val => {
            if(val > 1) {
                return val - 1;
            } else {
                clearInterval(this.getReadyInterval);
                this.beginRecordingAfterCountdown();
                return 0;
            }
        });
    }, 1000);
  }

  async beginRecordingAfterCountdown(): Promise<void> {
      this.interviewState.set('in-progress');
      await this.startRecordingForQuestion();
  }

  private stopMediaStreams() {
    this.videoStream()?.getTracks().forEach(track => track.stop());
    this.videoStream.set(null);
    this.audioStream()?.getTracks().forEach(track => track.stop());
    this.audioStream.set(null);
    clearInterval(this.timerInterval);

    if (this.videoPreview?.nativeElement) {
      this.videoPreview.nativeElement.srcObject = null;
    }

    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    if (this.audioContext?.state !== 'closed') {
      this.audioContext?.close().catch(e => console.error('Error closing audio context:', e));
    }
    this.audioContext = null;
    this.analyser = null;
    this.dataArray = null;

    this.stopQualityChecks();
  }
  
  private resetAnswerState(): void {
    if (this.mediaRecorder?.state !== 'inactive') this.mediaRecorder?.stop();
    if (this.isListening()) this.speechRecognition?.abort();
    
    clearInterval(this.timerInterval);
    this.timeRemaining.set(this.maxRecordingTime);
    this.timesUp.set(false);
    this.recordingStatus.set('idle');

    if (this.recordedUrl()) {
        URL.revokeObjectURL(this.recordedUrl()!);
    }
    this.recordedUrl.set(null);
    this.recordedBlob.set(null);
    this.recordedChunks = [];
    this.finalTranscript.set('');
    this.interimTranscript.set('');
  }

  discardCurrentAnswer(): void {
    this.resetAnswerState();
    this.stopMediaStreams();
    this.facingMode.set('user');
  }

  private handleMediaError(err: any, type: 'camera' | 'microphone' | 'media') {
    console.error(`Error accessing ${type}:`, err);
    let errorMessage = `Could not access the ${type}.`;
    
    if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        if (type === 'camera' || type === 'media') this.cameraPermission.set('denied');
        if (type === 'microphone' || type === 'media') this.micPermission.set('denied');
    }
    
    switch (err.name) {
        case 'NotAllowedError': case 'PermissionDeniedError':
            errorMessage = `Permission to access your ${type} was denied. Please check your browser settings.`; break;
        case 'NotFoundError':
            errorMessage = `No ${type} device was found. Please ensure your camera and microphone are connected properly.`; break;
        case 'NotReadableError':
            errorMessage = `Your ${type} device is currently in use by another application. Please close other apps and try again.`; break;
        case 'OverconstrainedError':
            errorMessage = `No ${type} device was found that meets the required specifications. Please try with a different device.`; break;
        case 'SecurityError':
            errorMessage = `Access to your ${type} is not possible from an insecure connection. Please use HTTPS.`; break;
        default:
            errorMessage = `An unexpected error occurred while accessing your ${type}: ${err.message || err.name}`; break;
    }

    this.geminiService.error.set(errorMessage);
    this.interviewState.set('error');
  }

  private async initializeVideoStream(forCheck: boolean = false): Promise<MediaStream | null> {
    try {
      this.stopMediaStreams();
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: this.facingMode() }, 
        audio: true
      });
      this.isMicMuted.set(false);
      this.videoStream.set(stream);
      this.cameraPermission.set('granted');
      this.micPermission.set('granted');
      
      this.audioStream.set(stream);
      this.setupAudioAnalyser(stream); // Set up analyser for quality check AND visualization
      this.checkCameraDevices();
      
      return stream;
    } catch (err: any) {
      this.handleMediaError(err, 'media');
      return null;
    }
  }
  
  async startRecordingForQuestion(): Promise<void> {
    this.resetAnswerState();
    
    let stream = this.videoStream();
    if (!stream) {
      stream = await this.initializeVideoStream();
      if (!stream) {
        this.interviewState.set('error');
        return;
      }
    }
    
    this.interviewService.enterFocusMode();

    this.mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) this.recordedChunks.push(event.data);
    };
    
    this.mediaRecorder.onstop = () => {
        this.interviewService.exitFocusMode();
        const blob = new Blob(this.recordedChunks, { type: 'video/webm' });
        this.recordedBlob.set(blob);
        const url = URL.createObjectURL(blob);
        this.recordedUrl.set(url);
        // Do not stop media streams here to allow for quick retakes/next questions
      };

    this.mediaRecorder.start();
    this.recordingStatus.set('recording');

    this.timesUp.set(false);
    this.timeRemaining.set(this.maxRecordingTime);
    this.timerInterval = setInterval(() => {
      this.timeRemaining.update(time => {
        if (time > 1) { return time - 1; } 
        else { this.timesUp.set(true); this.stopRecording(); return 0; }
      });
    }, 1000);
  }

  stopRecording(): void {
    if (!this.mediaRecorder || this.mediaRecorder.state === 'inactive') {
      return;
    }
    this.mediaRecorder.stop();
    this.recordingStatus.set('idle');
  }

  togglePauseResume(): void {
    if (!this.mediaRecorder) return;
    if (this.recordingStatus() === 'recording') {
      this.mediaRecorder.pause();
      clearInterval(this.timerInterval);
      this.recordingStatus.set('paused');
      this.interviewService.exitFocusMode();
    } else if (this.recordingStatus() === 'paused') {
      this.mediaRecorder.resume();
      this.timerInterval = setInterval(() => {
        this.timeRemaining.update(time => {
          if (time > 1) { return time - 1; } 
          else { this.timesUp.set(true); this.stopRecording(); return 0; }
        });
      }, 1000);
      this.recordingStatus.set('recording');
      this.interviewService.enterFocusMode();
    }
  }
  
  private simulateEvaluationProgress(): void {
      const steps: { text: string; status: 'in-progress' | 'done' | 'pending' }[] = [
        { text: 'Analyzing audio and transcribing speech...', status: 'in-progress' },
        { text: 'Evaluating response content for relevance...', status: 'pending' },
        { text: 'Assessing presentation and confidence from video...', status: 'pending' },
        { text: 'Compiling detailed feedback report...', status: 'pending' }
      ];
      this.evaluationProgressSteps.set(steps);

      const updateStep = (index: number) => {
        if (index >= steps.length) return;
        setTimeout(() => {
          this.evaluationProgressSteps.update(currentSteps => {
            const newSteps = [...currentSteps];
            if (newSteps[index - 1]) newSteps[index - 1].status = 'done';
            if (newSteps[index]) newSteps[index].status = 'in-progress';
            return newSteps;
          });
          updateStep(index + 1);
        }, 1500 + Math.random() * 1000);
      };
      updateStep(1);

      const messages = [
        'Analyzing vocal tone for confidence...',
        'Cross-referencing keywords with industry standards...',
        'Checking for clarity and conciseness...',
        'Assessing non-verbal cues from video...',
        'Finalizing the detailed report...'
      ];
      let messageIndex = 0;
      this.evaluationStatusMessage.set(messages[messageIndex]);
      this.statusInterval = setInterval(() => {
        messageIndex = (messageIndex + 1) % messages.length;
        this.evaluationStatusMessage.set(messages[messageIndex]);
      }, 2500);
  }


  async submitAnswer(): Promise<void> {
    if (this.finalTranscript().trim().length < 10 && !this.recordedBlob() && this.recordingStatus() === 'idle') {
        alert("Please provide a spoken answer (minimum 10 characters).");
        return;
    }
  
    if (this.recordingStatus() !== 'idle') {
        this.stopRecording();
    }
  
    this.interviewState.set('evaluating');
    this.simulateEvaluationProgress();
    const question = this.currentQuestion();
    const user = this.authService.currentUser();

    if (!question || !this.sessionId() || !user) {
        this.geminiService.error.set("Could not find the current question, session, or user.");
        this.interviewState.set('error');
        return;
    }
  
    const result = await this.geminiService.evaluateAnswer(question, {
        videoBlob: this.recordedBlob()!,
        text: this.finalTranscript()
    });
    
    clearInterval(this.statusInterval);
  
    if (result) {
        this.lastEvaluationResult.set(result);
        this.interviewService.addResult({
            sessionId: this.sessionId()!,
            questionId: question,
            questionText: question,
            evaluation: result,
            userName: user.name,
            company: user.company,
            jobTitle: this.interviewService.activeTemplate()?.jobTitle ?? 'N/A',
            category: this.interviewService.activeTemplate()?.category ?? 'N/A',
            experienceLevel: this.interviewService.activeTemplate()?.experienceLevel ?? 'N/A',
        });
        this.interviewState.set('feedback');
    } else {
        this.interviewState.set('error');
    }
  }

  async nextQuestion(): Promise<void> {
    this.resetAnswerState();
    this.lastEvaluationResult.set(null);
    if (this.currentQuestionIndex() < this.questions().length - 1) {
      this.currentQuestionIndex.update(i => i + 1);
      this.interviewState.set('get-ready');
      this.geminiService.error.set(null);
      this.showErrorDetails.set(false);
      this.confirmCameraReady();
    } else {
      this.stopMediaStreams();
      this.interviewState.set('completed');
      if (this.sessionId()) {
        this.interviewComplete.emit(this.sessionId()!);
      }
    }
  }

  async skipQuestion(): Promise<void> {
    this.resetAnswerState();
    if (this.currentQuestionIndex() < this.questions().length - 1) {
      this.currentQuestionIndex.update(i => i + 1);
      this.interviewState.set('get-ready');
      this.confirmCameraReady();
    } else {
      this.stopMediaStreams();
      this.interviewState.set('completed');
      if (this.sessionId()) {
        this.interviewComplete.emit(this.sessionId()!);
      }
    }
  }

  async retryLastQuestion(): Promise<void> {
    this.geminiService.error.set(null);
    this.interviewState.set('get-ready');
    this.showErrorDetails.set(false);
    this.confirmCameraReady();
  }
  
  async retakeAnswer(): Promise<void> {
    this.interviewState.set('get-ready');
    this.confirmCameraReady();
  }

  async toggleCameraFacingMode(): Promise<void> {
    if (this.recordingStatus() !== 'idle' && this.interviewState() !== 'camera-check') return;
    const newFacingMode = this.facingMode() === 'user' ? 'environment' : 'user';
    this.facingMode.set(newFacingMode);
    await this.initializeVideoStream(this.interviewState() === 'camera-check');
  }

  toggleMic(): void {
    const stream = this.videoStream();
    if (stream) {
      this.isMicMuted.update(muted => {
        const newMutedState = !muted;
        stream.getAudioTracks().forEach(track => {
          track.enabled = !newMutedState;
        });
        return newMutedState;
      });
    }
  }

  toggleErrorDetails(): void {
    this.showErrorDetails.update(val => !val);
  }

  private async checkCameraDevices(): Promise<void> {
    try {
        if (!navigator.mediaDevices?.enumerateDevices) { this.hasMultipleCameras.set(false); return; }
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoInputs = devices.filter(device => device.kind === 'videoinput');
        this.hasMultipleCameras.set(videoInputs.length > 1);
    } catch (err) {
        console.error("Error enumerating devices:", err);
        this.hasMultipleCameras.set(false);
    }
  }

  private setupAudioAnalyser(stream: MediaStream): void {
    try {
        if (!this.audioContext || this.audioContext.state === 'closed') {
            this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        if (this.analyser) { return; }

        this.analyser = this.audioContext.createAnalyser();
        this.analyser.fftSize = 256;
        this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
        const source = this.audioContext.createMediaStreamSource(stream);
        source.connect(this.analyser);
    } catch(e) { console.error("Error setting up audio analyser:", e); }
  }

  private setupAudioVisualization(): void {
    if (this.audioVisualizerCanvas?.nativeElement && !this.animationFrameId) {
        this.drawAudioVisualization();
    }
  }

  private drawAudioVisualization(): void {
    if (!this.analyser || !this.dataArray || !this.audioVisualizerCanvas?.nativeElement || this.recordingStatus() !== 'recording') {
      this.animationFrameId = null;
      return;
    }
    const canvas = this.audioVisualizerCanvas.nativeElement;
    const canvasCtx = canvas.getContext('2d');
    if (!canvasCtx) return;

    this.animationFrameId = requestAnimationFrame(() => this.drawAudioVisualization());

    this.analyser.getByteFrequencyData(this.dataArray);

    canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
    const barWidth = (canvas.width / this.analyser.frequencyBinCount) * 2.5;
    let x = 0;

    for (let i = 0; i < this.analyser.frequencyBinCount; i++) {
      const barHeight = this.dataArray[i] / 2;
      const gradient = canvasCtx.createLinearGradient(0, canvas.height, 0, 0);
      gradient.addColorStop(0, '#6A00FF');
      gradient.addColorStop(0.5, '#0057FF');
      gradient.addColorStop(1, '#001F3F');
      canvasCtx.fillStyle = gradient;
      canvasCtx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
      x += barWidth + 1;
    }
  }

  private stopAudioVisualization(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    if (this.audioVisualizerCanvas?.nativeElement) {
      const canvasCtx = this.audioVisualizerCanvas.nativeElement.getContext('2d');
      if (canvasCtx) {
        canvasCtx.clearRect(0, 0, this.audioVisualizerCanvas.nativeElement.width, this.audioVisualizerCanvas.nativeElement.height);
      }
    }
  }
  
  private startQualityChecks(): void {
    this.stopQualityChecks();
    this.qualityCheckInterval = setInterval(() => {
        this.checkLightQuality();
        this.checkAudioQuality();
    }, 1000);
  }

  private stopQualityChecks(): void {
    if (this.qualityCheckInterval) {
      clearInterval(this.qualityCheckInterval);
      this.qualityCheckInterval = null;
    }
    this.lightQuality.set('checking');
    this.audioQuality.set('checking');
  }
  
  private checkLightQuality(): void {
    if (!this.videoPreview?.nativeElement || !this.videoStream() || !this.qualityCheckCanvas?.nativeElement) return;

    const video = this.videoPreview.nativeElement;
    if (video.readyState < video.HAVE_METADATA || video.videoWidth === 0) return;

    const canvas = this.qualityCheckCanvas.nativeElement;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    try {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        let sum = 0;
        const step = 4 * 20;
        for (let i = 0; i < data.length; i += step) {
            const brightness = (data[i] + data[i + 1] + data[i + 2]) / 3;
            sum += brightness;
        }
        const avgBrightness = sum / (data.length / step);
        this.lightQuality.set(avgBrightness < 70 ? 'low' : 'good');
    } catch (e) {
        console.error("Could not get image data for light quality check:", e);
        this.lightQuality.set('checking');
    }
  }

  private checkAudioQuality(): void {
    if (this.isMicMuted()) { this.audioQuality.set('muted'); return; }
    if (!this.analyser || !this.dataArray) { this.audioQuality.set('checking'); return; }

    this.analyser.getByteFrequencyData(this.dataArray);
    let sum = 0;
    for (const amplitude of this.dataArray) { sum += amplitude; }
    const avgVolume = sum / this.dataArray.length;
    this.audioQuality.set(avgVolume < 10 ? 'low' : 'good');
  }

  getMetricColorClass(score: number): string {
    if (score >= 8) return 'bg-emerald-500';
    if (score >= 5) return 'bg-cyan-500';
    return 'bg-purple-500';
  }
}
