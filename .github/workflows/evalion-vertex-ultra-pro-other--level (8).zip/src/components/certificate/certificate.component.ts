import { ChangeDetectionStrategy, Component, computed, inject, signal, OnInit } from '@angular/core';
import { CommonModule, DatePipe, Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { InterviewService, InterviewResult } from '../../services/interview.service';
import { AuthService } from '../../services/auth.service';
import { HeaderComponent } from '../shared/header.component';

@Component({
  selector: 'app-certificate',
  standalone: true,
  templateUrl: './certificate.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, DatePipe, HeaderComponent],
})
export class CertificateComponent implements OnInit {
  private route: ActivatedRoute = inject(ActivatedRoute);
  private router: Router = inject(Router);
  private interviewService: InterviewService = inject(InterviewService);
  private location: Location = inject(Location);
  authService = inject(AuthService);

  sessionId = signal<string | null>(null);
  sessionResults = signal<InterviewResult[]>([]);
  
  sessionDetails = computed(() => {
    const results = this.sessionResults();
    if (results.length === 0) return null;
    
    const firstResult = results[0];
    const totalScore = results.reduce((sum, r) => sum + r.evaluation.score, 0);
    const overallScore = totalScore / results.length;
    
    return {
      candidateName: firstResult.userName,
      jobTitle: firstResult.jobTitle,
      date: firstResult.answeredOn,
      overallScore: overallScore,
      status: firstResult.status
    };
  });

  qrCodeUrl = computed(() => {
    if (!this.sessionId()) return '';
    // In a real app, this would be the public URL of the verification page.
    const verificationUrl = `${window.location.origin}${window.location.pathname}#/certificate/${this.sessionId()}`;
    return `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(verificationUrl)}`;
  });

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('sessionId');
    this.sessionId.set(id);
    if (id) {
      const allResults = this.interviewService.getResults();
      const resultsForSession = allResults.filter(r => r.sessionId === id);
      if (resultsForSession.length > 0) {
        // Security check: ensure the logged-in user is either the candidate or an admin
        const currentUser = this.authService.currentUser();
        const isOwner = currentUser?.name === resultsForSession[0].userName;
        const isAdmin = currentUser?.role === 'super-admin' || currentUser?.role === 'content-manager';

        if (isOwner || isAdmin) {
           if (resultsForSession[0].status === 'approved') {
               this.sessionResults.set(resultsForSession);
           } else {
                alert('This certificate is not yet approved or has been rejected.');
                this.router.navigate(['/candidate']);
           }
        } else {
          alert('You do not have permission to view this certificate.');
          this.router.navigate(['/candidate']);
        }
      } else {
        alert('Certificate not found.');
        this.router.navigate(['/candidate']);
      }
    }
  }

  printCertificate(): void {
    window.print();
  }

  goBack(): void {
    this.location.back();
  }
}