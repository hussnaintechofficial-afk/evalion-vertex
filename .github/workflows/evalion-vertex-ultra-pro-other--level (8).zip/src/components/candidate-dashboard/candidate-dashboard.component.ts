import { ChangeDetectionStrategy, Component, computed, inject, signal, effect, OnInit, AfterViewInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { CommonModule, Location, DOCUMENT, DatePipe } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { InterviewComponent } from '../interview/interview.component';
import { ChatbotComponent } from '../chatbot/chatbot.component';
import { AuthService, User } from '../../services/auth.service';
import { InterviewService, InterviewResult, InterviewTemplate } from '../../services/interview.service';
import { ConfirmationDialogComponent } from '../shared/confirmation-dialog.component';
import { ThemeService } from '../../services/theme.service';
import { ThemeCustomizerComponent } from '../shared/theme-customizer.component';
import { HeaderComponent } from '../shared/header.component';
import { FooterComponent } from '../shared/footer.component';

declare var Chart: any;

type DashboardView = 'overview' | 'practice' | 'history' | 'profile' | 'theme-settings' | 'results-summary';

@Component({
  selector: 'app-candidate-dashboard',
  standalone: true,
  imports: [CommonModule, InterviewComponent, ChatbotComponent, DatePipe, ReactiveFormsModule, ConfirmationDialogComponent, ThemeCustomizerComponent, HeaderComponent, FooterComponent],
  templateUrl: './candidate-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CandidateDashboardComponent implements OnInit, AfterViewInit, OnDestroy {
  authService = inject(AuthService);
  interviewService = inject(InterviewService);
  themeService = inject(ThemeService);
  private location = inject(Location);
  private fb: FormBuilder = inject(FormBuilder);
  private router: Router = inject(Router);

  @ViewChild('performanceChart', { static: false }) performanceChart!: ElementRef<HTMLCanvasElement>;
  private chartInstance: any;

  view = signal<DashboardView>('practice');
  isLoadingView = signal(false);
  pastResults = signal<InterviewResult[]>([]);
  expandedResult = signal<string | null>(null);

  isPracticing = signal(false);
  isUserMenuOpen = signal(false);

  // --- Filtering State ---
  jobTitleFilter = signal<string>('');
  categoryFilter = signal<string>('');
  experienceFilter = signal<string>('');
  typeFilter = signal<string>('');

  // Templates are now filtered by company
  availableTemplates = computed(() => {
    const allTemplates = this.interviewService.getInterviewTemplates();
    const userCompany = this.authService.currentUser()?.company;
    return allTemplates.filter(t => !t.company || t.company === userCompany);
  });
  
  uniqueJobTitles = computed(() => [...new Set(this.availableTemplates().map(t => t.jobTitle))]);
  uniqueCategories = computed(() => [...new Set(this.availableTemplates().map(t => t.category))]);
  uniqueExperienceLevels = computed(() => [...new Set(this.availableTemplates().map(t => t.experienceLevel))]);
  uniqueTypes = computed(() => [...new Set(this.availableTemplates().map(t => t.type))]);

  filteredTemplates = computed(() => {
    const templates = this.availableTemplates();
    const jobTitle = this.jobTitleFilter().toLowerCase();
    const category = this.categoryFilter().toLowerCase();
    const experience = this.experienceFilter();
    const type = this.typeFilter();

    return templates.filter(template => {
      const jobTitleMatch = !jobTitle || template.jobTitle.toLowerCase().includes(jobTitle);
      const categoryMatch = !category || template.category.toLowerCase().includes(category);
      // Use strict equality for select dropdowns, which is cleaner and more performant.
      const experienceMatch = !experience || template.experienceLevel === experience;
      const typeMatch = !type || template.type === type;
      return jobTitleMatch && categoryMatch && experienceMatch && typeMatch;
    });
  });

  completedCount = computed(() => this.pastResults().length);
  averageScore = computed(() => {
    const results = this.pastResults();
    if (results.length === 0) return 0;
    const total = results.reduce((sum, result) => sum + result.evaluation.score, 0);
    return total / results.length;
  });
  highestScore = computed(() => {
    const results = this.pastResults();
    if (results.length === 0) return 0;
    return Math.max(...results.map(r => r.evaluation.score));
  });

  showLogoutConfirm = signal(false);

  // --- Profile State ---
  profileForm = this.fb.group({
    name: ['', Validators.required],
    fatherName: [''],
    dob: [''],
    cnic: [''],
    mobile: [''],
    photoUrl: ['']
  });
  isEditingProfile = signal(false);
  profileUpdateStatus = signal<{ message: string, type: 'success' | 'error' } | null>(null);

  // --- Results Summary State ---
  lastCompletedSessionId = signal<string | null>(null);
  sessionResults = computed(() => {
      const sessionId = this.lastCompletedSessionId();
      if (!sessionId) return [];
      // Get the latest results for the session
      const user = this.authService.currentUser();
      const allUserResults = this.interviewService.getResults().filter(r => r.userName === user?.name);
      return allUserResults.filter(r => r.sessionId === sessionId);
  });
  sessionOverallScore = computed(() => {
      const results = this.sessionResults();
      if (results.length === 0) return 0;
      const total = results.reduce((sum, result) => sum + result.evaluation.score, 0);
      return total / results.length;
  });
  sessionVerdict = computed(() => {
      const score = this.sessionOverallScore();
      if (score >= 8) return { text: 'Passed', color: 'text-emerald-400' };
      if (score >= 5) return { text: 'Average', color: 'text-cyan-400' };
      return { text: 'Failed', color: 'text-purple-400' };
  });
  
  // --- History State ---
  groupedResults = computed(() => {
    const groups = new Map<string, { results: InterviewResult[], overallScore: number, status: string, jobTitle: string, date: string }>();
    this.pastResults().forEach(result => {
        if (!groups.has(result.sessionId)) {
            groups.set(result.sessionId, { results: [], overallScore: 0, status: result.status, jobTitle: result.jobTitle, date: result.answeredOn });
        }
        groups.get(result.sessionId)!.results.push(result);
    });
    groups.forEach(group => {
        const total = group.results.reduce((sum, r) => sum + r.evaluation.score, 0);
        group.overallScore = total / group.results.length;
    });
    return Array.from(groups.values()).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });


  constructor() {
     effect(() => {
      // Re-render chart if theme, results, or loading state change
      this.pastResults();
      this.themeService.mode();
      const isLoading = this.isLoadingView();

      if (!isLoading && this.view() === 'overview' && this.performanceChart?.nativeElement) {
        this.destroyChart();
        this.createChart();
      }
    });

    // Populate profile form when user data is available
    effect(() => {
      const user = this.authService.currentUser();
      if (user) {
        this.profileForm.patchValue({
          name: user.name,
          fatherName: user.fatherName,
          dob: user.dob,
          cnic: user.cnic,
          mobile: user.mobile,
          photoUrl: user.photoUrl,
        });
      }
    });
  }
  
  ngOnInit(): void {
    const user = this.authService.currentUser();
    this.pastResults.set(this.interviewService.getResults().filter(r => r.userName === user?.name));
  }

  ngAfterViewInit(): void {
    if (this.view() === 'overview') {
       this.createChart();
    }
  }

  ngOnDestroy(): void {
    this.destroyChart();
  }
  
  startPractice(templateId: string): void {
    if (this.interviewService.startInterviewSession(templateId)) {
        this.isPracticing.set(true);
    } else {
        alert("Could not start interview. The selected template has no questions.");
    }
  }

  handleInterviewCompletion(sessionId: string): void {
    const user = this.authService.currentUser();
    this.pastResults.set(this.interviewService.getResults().filter(r => r.userName === user?.name)); // Refresh results
    this.lastCompletedSessionId.set(sessionId);
    this.isPracticing.set(false);
    this.setView('results-summary');
  }

  private destroyChart(): void {
    if (this.chartInstance) {
      this.chartInstance.destroy();
      this.chartInstance = null;
    }
  }

  private createChart(): void {
    if (!this.performanceChart?.nativeElement || this.pastResults().length === 0) return;
    
    setTimeout(() => {
      if (!this.performanceChart?.nativeElement) return;
      const ctx = this.performanceChart.nativeElement.getContext('2d');
      if (!ctx) return;
      
      const isLightTheme = this.themeService.mode() === 'light';
      const gridColor = isLightTheme ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255, 255, 255, 0.1)';
      const labelColor = isLightTheme ? '#374151' : '#E5E7EB';
      
      const reversedResults = [...this.pastResults()].reverse();
      const labels = reversedResults.map((_, i) => `Attempt ${i + 1}`);
      
      // Data for multiple metrics
      const overallScores = reversedResults.map(r => r.evaluation.score);
      const accuracyScores = reversedResults.map(r => r.evaluation.metrics.accuracy.score);
      const clarityScores = reversedResults.map(r => r.evaluation.metrics.clarity.score);
      const confidenceScores = reversedResults.map(r => r.evaluation.metrics.confidence.score);

      const createGradient = (color: string) => {
        const gradient = ctx.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, `${color}60`); // 60% opacity
        gradient.addColorStop(1, `${color}10`); // 10% opacity
        return gradient;
      };

      this.chartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Overall Score',
              data: overallScores,
              backgroundColor: createGradient('#22D3EE'), // Cyan
              borderColor: '#22D3EE',
              borderWidth: 2,
              pointBackgroundColor: '#FFFFFF',
              pointBorderColor: '#22D3EE',
              pointHoverBackgroundColor: '#22D3EE',
              pointHoverBorderColor: '#FFFFFF',
              tension: 0.4,
              fill: true,
            },
            {
              label: 'Accuracy',
              data: accuracyScores,
              borderColor: '#10B981', // Emerald
              borderWidth: 1.5,
              pointBackgroundColor: '#FFFFFF',
              pointBorderColor: '#10B981',
              pointHoverBackgroundColor: '#10B981',
              pointHoverBorderColor: '#FFFFFF',
              tension: 0.4,
              fill: false,
            },
            {
              label: 'Clarity',
              data: clarityScores,
              borderColor: '#8B5CF6', // Violet
              borderWidth: 1.5,
              pointBackgroundColor: '#FFFFFF',
              pointBorderColor: '#8B5CF6',
              pointHoverBackgroundColor: '#8B5CF6',
              pointHoverBorderColor: '#FFFFFF',
              tension: 0.4,
              fill: false,
            },
            {
              label: 'Confidence',
              data: confidenceScores,
              borderColor: '#F59E0B', // Amber
              borderWidth: 1.5,
              pointBackgroundColor: '#FFFFFF',
              pointBorderColor: '#F59E0B',
              pointHoverBackgroundColor: '#F59E0B',
              pointHoverBorderColor: '#FFFFFF',
              tension: 0.4,
              fill: false,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: true, // Show legend for multiple datasets
              labels: {
                color: labelColor,
              },
            },
          },
          scales: {
            y: {
              beginAtZero: true,
              max: 10,
              grid: {
                color: gridColor,
              },
              ticks: {
                color: labelColor,
              },
            },
            x: {
              grid: {
                display: false,
              },
              ticks: {
                color: labelColor,
              },
            },
          },
        },
      });
    }, 10);
  }

  confirmLogout(): void {
    this.showLogoutConfirm.set(true);
    this.isUserMenuOpen.set(false);
  }
  
  logout(confirmed: boolean): void {
    if(confirmed) {
      this.authService.logout();
    }
    this.showLogoutConfirm.set(false);
  }

  goBack(): void {
    this.location.back();
  }
  
  setView(newView: DashboardView): void {
    this.isUserMenuOpen.set(false);
    if (this.view() === newView) { return; }
    
    this.isLoadingView.set(true);
    this.isPracticing.set(false);
    this.isEditingProfile.set(false);

    // Short delay to show loading animation and improve perceived performance
    setTimeout(() => {
      this.view.set(newView);
      this.isLoadingView.set(false);
    }, 300);
  }
  
  toggleResultExpansion(sessionId: string): void {
    this.expandedResult.update(current => current === sessionId ? null : sessionId);
  }
  
  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        this.profileForm.patchValue({ photoUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  }

  async saveProfile(): Promise<void> {
    if (this.profileForm.invalid) {
      this.profileUpdateStatus.set({ message: 'Please ensure all required fields are filled correctly.', type: 'error'});
      return;
    }
    const success = await this.authService.updateUserProfile(this.profileForm.value);
    if (success) {
      this.profileUpdateStatus.set({ message: 'Profile updated successfully!', type: 'success'});
      this.isEditingProfile.set(false);
    } else {
      this.profileUpdateStatus.set({ message: 'Failed to update profile. Please try again.', type: 'error'});
    }
    setTimeout(() => this.profileUpdateStatus.set(null), 3000);
  }
  
  onJobTitleFilterChange(event: Event): void {
    this.jobTitleFilter.set((event.target as HTMLInputElement).value);
  }

  onCategoryFilterChange(event: Event): void {
    this.categoryFilter.set((event.target as HTMLInputElement).value);
  }

  onExperienceFilterChange(event: Event): void {
    this.experienceFilter.set((event.target as HTMLSelectElement).value);
  }

  onTypeFilterChange(event: Event): void {
    this.typeFilter.set((event.target as HTMLSelectElement).value);
  }

  resetFilters(): void {
    this.jobTitleFilter.set('');
    this.categoryFilter.set('');
    this.experienceFilter.set('');
    this.typeFilter.set('');
  }
  
  getScoreColorClass(score: number): string {
    if (score >= 8) return 'text-emerald-400';
    if (score >= 5) return 'text-cyan-400';
    return 'text-purple-400';
  }
  
  getScoreGradientClass(score: number): string {
    if (score >= 8) return 'from-emerald-400 to-green-500';
    if (score >= 5) return 'from-cyan-400 to-blue-500';
    return 'from-purple-400 to-indigo-500';
  }
  
  viewCertificate(sessionId: string): void {
    this.router.navigate(['/certificate', sessionId]);
  }
}