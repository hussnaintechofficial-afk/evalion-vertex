import { ChangeDetectionStrategy, Component, computed, inject, signal, OnInit, effect } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, User, UserRole } from '../../services/auth.service';
import { InterviewService, InterviewTemplate, InterviewResult, InterviewTemplateType } from '../../services/interview.service';
import { GeminiService } from '../../services/gemini.service';
import { ConfirmationDialogComponent } from '../shared/confirmation-dialog.component';
import { ThemeCustomizerComponent } from '../shared/theme-customizer.component';
import { HeaderComponent } from '../shared/header.component';
import { ThemeService } from '../../services/theme.service';
import { FooterComponent } from '../shared/footer.component';

type AdminDashboardView = 'templates' | 'performance' | 'users' | 'theme-settings';

interface SessionGroup {
  sessionId: string;
  results: InterviewResult[];
  overallScore: number;
  status: 'pending' | 'approved' | 'rejected';
  jobTitle: string;
  date: string;
  userName: string;
  user: User | null;
  company?: string;
}

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DatePipe, ConfirmationDialogComponent, ThemeCustomizerComponent, HeaderComponent, FooterComponent],
  templateUrl: './admin-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminDashboardComponent implements OnInit {
  authService = inject(AuthService);
  interviewService = inject(InterviewService);
  geminiService = inject(GeminiService);
  themeService = inject(ThemeService);
  private router = inject(Router);
  private fb: FormBuilder = inject(FormBuilder);
  
  view = signal<AdminDashboardView>('templates');
  isLoadingView = signal(false);
  currentYear = new Date().getFullYear();
  isUserMenuOpen = signal(false);
  currentUser = this.authService.currentUser;

  // --- Role-Based Access ---
  isSuperAdmin = computed(() => this.currentUser()?.role === 'super-admin');
  canManageTemplates = computed(() => {
    const role = this.currentUser()?.role;
    return role === 'super-admin' || role === 'content-manager';
  });
  
  // --- Template Management State ---
  templates = computed(() => {
    const allTemplates = this.interviewService.getInterviewTemplates();
    if (this.isSuperAdmin()) {
      return allTemplates;
    }
    const adminCompany = this.currentUser()?.company;
    return allTemplates.filter(t => t.company === adminCompany);
  });

  isGenerating = signal(false);
  generationError = signal<string | null>(null);
  expandedTemplateId = signal<string | null>(null);
  // FIX: Added the missing `expandedResultId` signal to fix a property access error.
  expandedResultId = signal<string | null>(null);
  templateToDelete = signal<InterviewTemplate | null>(null);
  showLogoutConfirm = signal(false);

  templateForm = this.fb.group({
    jobTitle: ['', Validators.required],
    category: ['Software Engineering', Validators.required],
    experienceLevel: ['Senior', Validators.required],
    questionCount: [5, [Validators.required, Validators.min(1), Validators.max(10)]],
    type: ['technical' as InterviewTemplateType, Validators.required]
  });

  // --- Performance View State ---
  groupedSessions = computed<SessionGroup[]>(() => {
    const groups = new Map<string, SessionGroup>();
    const allUsers = this.authService.getAllUsers();
    
    let results = this.interviewService.getResults();
    // Filter results by company if not a super admin
    if (!this.isSuperAdmin()) {
      const adminCompany = this.currentUser()?.company;
      results = results.filter(r => r.company === adminCompany);
    }

    results.forEach(result => {
        if (!groups.has(result.sessionId)) {
            const user = allUsers.find(u => u.name === result.userName) || null;
            groups.set(result.sessionId, { 
                sessionId: result.sessionId,
                results: [], 
                overallScore: 0, 
                status: result.status, 
                jobTitle: result.jobTitle, 
                date: result.answeredOn,
                userName: result.userName,
                user: user,
                company: result.company,
            });
        }
        groups.get(result.sessionId)!.results.push(result);
    });

    groups.forEach(group => {
        // Fix: Access evaluation.score from InterviewResult
        const total = group.results.reduce((sum, r) => sum + r.evaluation.score, 0);
        group.overallScore = total / group.results.length;
    });

    return Array.from(groups.values()).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });
  
  // --- Analytics for results ---
  filteredTotalSubmissions = computed(() => this.groupedSessions().length);
  filteredAverageScore = computed(() => {
    const sessions = this.groupedSessions();
    if (sessions.length === 0) return 0;
    const total = sessions.reduce((sum, r) => sum + r.overallScore, 0);
    return total / sessions.length;
  });

  // --- User Management State ---
  allUsers = computed(() => {
    const users = this.authService.getAllUsers();
    if (this.isSuperAdmin()) {
      return users;
    }
    const adminCompany = this.currentUser()?.company;
    return users.filter(u => u.company === adminCompany);
  });
  userToToggleStatus = signal<User | null>(null); // For confirmation dialog
  showUserStatusConfirm = signal(false);
  sessionToUpdate = signal<{ session: SessionGroup, action: 'approve' | 'reject' } | null>(null);
  showSessionConfirm = signal(false);
  availableRoles: UserRole[] = ['candidate', 'content-manager', 'super-admin'];

  // --- New User Creation State ---
  showCreateUserForm = signal(false);
  newUserForm = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]],
    role: ['candidate' as UserRole, Validators.required],
    companyName: [''], // Conditional validation
    companyLogo: [''], // Conditional validation (Base64 string)
    companyRegistrationNumber: [''] // Conditional validation
  });
  newCompanyLogoPreview = signal<string | null>(null);
  createUserStatus = signal<{ message: string, type: 'success' | 'error' } | null>(null);

  constructor() {
    // Effect for dynamic validation on newUserForm company fields
    effect(() => {
      const roleControl = this.newUserForm.get('role');
      const companyNameControl = this.newUserForm.get('companyName');
      const companyLogoControl = this.newUserForm.get('companyLogo');
      const companyRegNoControl = this.newUserForm.get('companyRegistrationNumber');

      if (!roleControl || !companyNameControl || !companyLogoControl || !companyRegNoControl) return;

      const role = roleControl.value;
      if (role === 'super-admin' || role === 'content-manager') {
        companyNameControl.addValidators(Validators.required);
        companyLogoControl.addValidators(Validators.required);
        companyRegNoControl.addValidators(Validators.required);
      } else {
        companyNameControl.removeValidators(Validators.required);
        companyLogoControl.removeValidators(Validators.required);
        companyRegNoControl.removeValidators(Validators.required);
      }
      // Re-run validation immediately after changing validators
      companyNameControl.updateValueAndValidity();
      companyLogoControl.updateValueAndValidity();
      companyRegNoControl.updateValueAndValidity();
    });
  }

  ngOnInit(): void {
    // Data is now loaded via computed signals based on services.
  }

  confirmLogout(): void {
    this.showLogoutConfirm.set(true);
    this.isUserMenuOpen.set(false);
  }

  handleLogout(confirmed: boolean): void {
    if (confirmed) {
      this.authService.logout();
    }
    this.showLogoutConfirm.set(false);
  }
  
  setView(newView: AdminDashboardView): void {
    this.isUserMenuOpen.set(false);
    if (this.view() === newView) { return; }

    this.isLoadingView.set(true);

    setTimeout(() => {
      this.view.set(newView);
      this.isLoadingView.set(false);
    }, 300);
  }

  goBack(): void {
    this.setView('templates');
  }

  async generateAndSaveTemplate(): Promise<void> {
    if (this.templateForm.invalid) {
      this.templateForm.markAllAsTouched();
      return;
    }
    
    this.isGenerating.set(true);
    this.generationError.set(null);
    const { jobTitle, category, experienceLevel, questionCount, type } = this.templateForm.value;
    
    const adminUser = this.currentUser();
    if (!adminUser) {
        this.generationError.set("Cannot generate template: User not logged in.");
        this.isGenerating.set(false);
        return;
    }

    const questions = await this.geminiService.generateInterviewQuestions(
      jobTitle!, category!, experienceLevel!, questionCount!
    );

    if (questions) {
      this.interviewService.addInterviewTemplate({
        jobTitle: jobTitle!,
        category: category!,
        experienceLevel: experienceLevel!,
        questions: questions,
        type: type!
      }, adminUser);
      this.templateForm.reset({ category: 'Software Engineering', experienceLevel: 'Senior', questionCount: 5, type: 'technical' });
    } else {
      this.generationError.set(this.geminiService.error() || 'An unknown error occurred during question generation.');
    }
    
    this.isGenerating.set(false);
  }

  confirmDeleteTemplate(template: InterviewTemplate): void {
    this.templateToDelete.set(template);
  }
  
  handleDelete(confirmed: boolean): void {
    if (confirmed && this.templateToDelete()) {
      this.interviewService.deleteInterviewTemplate(this.templateToDelete()!.id);
    }
    this.templateToDelete.set(null);
  }
  
  toggleTemplateExpansion(templateId: string): void {
    this.expandedTemplateId.update(current => (current === templateId ? null : templateId));
  }
  
  toggleResultExpansion(sessionId: string): void {
    this.expandedResultId.update(current => (current === sessionId ? null : sessionId));
  }
  
  confirmUpdateSession(session: SessionGroup, action: 'approve' | 'reject'): void {
    this.sessionToUpdate.set({ session, action });
    this.showSessionConfirm.set(true);
  }

  async handleUpdateSession(confirmed: boolean): Promise<void> {
    const update = this.sessionToUpdate();
    if (confirmed && update) {
      if (update.action === 'approve') {
        await this.interviewService.approveSessionResults(update.session.sessionId);
      } else {
        await this.interviewService.rejectSessionResults(update.session.sessionId);
      }
    }
    this.sessionToUpdate.set(null);
    this.showSessionConfirm.set(false);
  }
  
  viewCertificate(sessionId: string): void {
    this.router.navigate(['/certificate', sessionId]);
  }


  // --- User Management Methods ---
  confirmToggleUserStatus(user: User): void {
    this.userToToggleStatus.set(user);
    this.showUserStatusConfirm.set(true);
  }

  async handleToggleUserStatus(confirmed: boolean): Promise<void> {
    if (confirmed && this.userToToggleStatus()) {
      await this.authService.toggleUserStatus(this.userToToggleStatus()!.id);
    }
    this.userToToggleStatus.set(null);
    this.showUserStatusConfirm.set(false);
  }

  async changeUserRole(userId: string, event: Event): Promise<void> {
    const newRole = (event.target as HTMLSelectElement).value as UserRole;
    if (!await this.authService.updateUserRole(userId, newRole)) {
      alert("Role could not be changed. Super Admins cannot change their own role.");
    }
  }

  onNewUserFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        this.newCompanyLogoPreview.set(result);
        this.newUserForm.patchValue({ companyLogo: result });
      };
      reader.readAsDataURL(file);
    }
  }

  async createUser(): Promise<void> {
    if (this.newUserForm.invalid) {
      this.newUserForm.markAllAsTouched();
      this.createUserStatus.set({ message: 'Please correct the errors in the form.', type: 'error' });
      return;
    }

    this.createUserStatus.set(null);
    const userData = this.newUserForm.value;

    const userToCreate: Omit<User, 'id' | 'disabled'> = {
        name: userData.name!,
        email: userData.email!,
        password: userData.password!,
        role: userData.role!,
        company: userData.companyName || '', 
        companyName: userData.companyName || undefined,
        companyLogo: userData.companyLogo || undefined,
        companyRegistrationNumber: userData.companyRegistrationNumber || undefined,
    };

    const result = await this.authService.createUser(userToCreate);
    if (result.success) {
      this.createUserStatus.set({ message: result.message, type: 'success' });
      this.resetNewUserForm();
    } else {
      this.createUserStatus.set({ message: result.message, type: 'error' });
    }
    setTimeout(() => this.createUserStatus.set(null), 3000); 
  }

  resetNewUserForm(): void {
    this.newUserForm.reset({
      name: '',
      email: '',
      password: '',
      role: 'candidate',
      companyName: '',
      companyLogo: '',
      companyRegistrationNumber: ''
    });
    this.newCompanyLogoPreview.set(null);
    this.showCreateUserForm.set(false); 
  }

  
  // --- Styling Helpers ---
  getScoreColorClass(score: number): string {
    if (score >= 8) return 'text-emerald-400';
    if (score >= 5) return 'text-cyan-400';
    return 'text-purple-400';
  }
  
  getScoreGradientClass(score: number): string {
    if (score >= 8) return 'from-emerald-400 to-green-500';
    if (score >= 5) return 'from-cyan-400 to-blue-500';
    return 'from-purple-400 to-indigo-500';
  }
}