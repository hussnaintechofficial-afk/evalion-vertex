import { Injectable, signal, effect } from '@angular/core';
import { EvaluationResult } from './gemini.service';
import { User } from './auth.service';

export type InterviewTemplateType = 'technical' | 'behavioral' | 'situational' | 'general';

export interface InterviewQuestion {
  id: string;
  text: string;
}

export interface InterviewTemplate {
  id:string;
  jobTitle: string;
  category: string;
  experienceLevel: string;
  questions: string[];
  createdAt: string; // ISO string date
  type: InterviewTemplateType;
  company?: string;
  authorId?: string;
  authorName?: string;
}

export interface InterviewResult {
  sessionId: string;
  status: 'pending' | 'approved' | 'rejected';
  questionId: string;
  questionText: string;
  evaluation: EvaluationResult;
  answeredOn: string; // ISO string date
  userName: string;
  jobTitle: string; // Added for filtering
  category: string;  // Added for filtering
  experienceLevel: string; // Added for filtering
  company?: string;
}

const seniorSoftwareEngineerTemplate: InterviewTemplate = {
  id: 'template_senior_swe',
  jobTitle: 'Senior Software Engineer',
  category: 'Software Engineering',
  experienceLevel: 'Senior',
  createdAt: new Date().toISOString(),
  type: 'technical',
  company: 'HussnainTechVertex Pvt Ltd.',
  questions: [
    "Describe a complex software system you have designed or significantly contributed to. What were the major architectural decisions and trade-offs you made?",
    "How do you approach mentoring junior engineers and promoting best practices within a team?",
    "Explain the principles of SOLID design. Provide an example of how you have applied the 'Single Responsibility Principle' in a real-world project.",
    "Discuss your experience with microservices. What are the benefits and drawbacks of this architectural style, and how do you handle challenges like data consistency and service discovery?",
    "How would you design a scalable and resilient API rate-limiting system?"
  ]
};

const midLevelFullStackTemplate: InterviewTemplate = {
  id: 'template_mid_fullstack',
  jobTitle: 'Full Stack Developer',
  category: 'Software Engineering',
  experienceLevel: 'Mid-Level',
  createdAt: new Date().toISOString(),
  type: 'technical',
  company: 'HussnainTechVertex Pvt Ltd.',
  questions: [
    "Explain the event loop in Node.js. How does it handle asynchronous operations?",
    "What is the difference between SQL and NoSQL databases? Provide an example of when you would choose one over the other.",
    "Describe your process for building a RESTful API. What are the key principles you follow?",
    "How do you ensure security in a web application? Discuss topics like XSS, CSRF, and SQL injection.",
    "What are Angular Interceptors and for what purposes have you used them?",
    "Explain the concept of state management on the frontend. What solutions have you used (e.g., NgRx, services with signals/subjects) and what are their pros and cons?",
    "Describe your experience with containerization using Docker. How does it help in development and deployment?",
    "What is CI/CD? Describe a CI/CD pipeline you have worked with.",
    "How do you optimize a web application for performance? Discuss both frontend and backend strategies.",
    "You've been tasked with building a real-time chat feature. What technologies and architecture would you consider?"
  ]
};

const juniorFrontendDeveloperTemplate: InterviewTemplate = {
  id: 'template_junior_frontend',
  jobTitle: 'Junior Frontend Developer',
  category: 'Web Development',
  experienceLevel: 'Entry-Level',
  createdAt: new Date().toISOString(),
  type: 'technical',
  company: 'Global Tech Inc.',
  questions: [
    "What are the differences between `null` and `undefined` in JavaScript?",
    "Explain the CSS box model and how `box-sizing: border-box;` changes it.",
    "What is 'semantic HTML' and why is it important for accessibility and SEO?",
    "Can you describe what a closure is in JavaScript and provide a simple example?",
    "How would you handle an asynchronous API call in a modern frontend framework like Angular, React, or Vue?"
  ]
};

const devOpsEngineerTemplate: InterviewTemplate = {
  id: 'template_mid_devops',
  jobTitle: 'DevOps Engineer',
  category: 'Infrastructure',
  experienceLevel: 'Mid-Level',
  createdAt: new Date().toISOString(),
  type: 'technical',
  company: 'HussnainTechVertex Pvt Ltd.',
  questions: [
    "Explain the concept of Infrastructure as Code (IaC) and describe your experience with tools like Terraform or CloudFormation.",
    "What is a CI/CD pipeline? Walk me through the stages of a typical pipeline you have built or managed.",
    "Describe the differences between containers (e.g., Docker) and virtual machines. When would you choose one over the other?",
    "How do you handle secrets management in your infrastructure and applications?",
    "What monitoring and logging tools are you familiar with, and how do you use them to ensure system health and reliability?",
    "Explain the role of Kubernetes in a modern infrastructure. What are some core components like Pods, Services, and Deployments?",
    "You've received an alert that a production service is down. What are your first steps to diagnose and mitigate the issue?"
  ]
};

const initialDefaultTemplate: InterviewTemplate = {
  id: 'template_default',
  jobTitle: 'General Tech Practice',
  category: 'General',
  experienceLevel: 'Entry-Level',
  createdAt: new Date().toISOString(),
  type: 'general',
  questions: [
    "Can you explain the difference between `let`, `const`, and `var` in JavaScript?",
    "What is the purpose of the `async` and `await` keywords in TypeScript?",
    "Describe the concept of dependency injection in Angular.",
    "What are Angular Signals and how do they improve change detection?",
    "Explain the 'box model' in CSS."
  ]
};

const INITIAL_TEMPLATES = [seniorSoftwareEngineerTemplate, midLevelFullStackTemplate, juniorFrontendDeveloperTemplate, devOpsEngineerTemplate, initialDefaultTemplate];

@Injectable({
  providedIn: 'root'
})
export class InterviewService {
  private readonly TEMPLATES_STORAGE_KEY = 'evalion_templates';
  private readonly RESULTS_STORAGE_KEY = 'evalion_results';

  // This signal now holds interview templates
  interviewTemplates = signal<InterviewTemplate[]>([]);
  results = signal<InterviewResult[]>([]);
  
  // This is now a temporary holder for the questions of the *active* interview
  activeQuestions = signal<string[]>([]);
  activeTemplate = signal<InterviewTemplate | null>(null); // Track the active template
  
  // Public signal to indicate if the app should be in "focus mode"
  isFocusMode = signal<boolean>(false);

  constructor() {
    this.loadFromLocalStorage();

    // Persist to localStorage whenever signals change
    effect(() => {
      this.saveToLocalStorage(this.TEMPLATES_STORAGE_KEY, this.interviewTemplates());
      this.saveToLocalStorage(this.RESULTS_STORAGE_KEY, this.results());
    });
  }

  // --- Focus Mode Management ---
  enterFocusMode(): void {
    this.isFocusMode.set(true);
  }

  exitFocusMode(): void {
    this.isFocusMode.set(false);
  }

  // --- Template Management (Admin) ---

  getInterviewTemplates(): InterviewTemplate[] {
    return this.interviewTemplates();
  }
  
  addInterviewTemplate(templateData: Omit<InterviewTemplate, 'id' | 'createdAt' | 'company' | 'authorId' | 'authorName'>, author: User): void {
    const newTemplate: InterviewTemplate = {
      ...templateData,
      id: `template_${Date.now()}`,
      createdAt: new Date().toISOString(),
      company: author.company,
      authorId: author.id,
      authorName: author.name
    };
    this.interviewTemplates.update(current => [newTemplate, ...current]);
  }
  
  deleteInterviewTemplate(id: string): void {
    this.interviewTemplates.update(current => current.filter(t => t.id !== id));
  }
  
  // --- Active Interview Management (Candidate) ---
  
  startInterviewSession(templateId: string): boolean {
    const template = this.interviewTemplates().find(t => t.id === templateId);
    if (template && template.questions.length > 0) {
      this.activeQuestions.set(template.questions);
      this.activeTemplate.set(template); // Set the active template
      return true;
    }
    this.activeQuestions.set([]);
    this.activeTemplate.set(null);
    return false;
  }
  
  getActiveQuestions(): string[] {
    return this.activeQuestions();
  }


  // --- Result Management (Candidate & Admin) ---

  getResults(): InterviewResult[] {
    return this.results();
  }

  addResult(result: Omit<InterviewResult, 'answeredOn' | 'status'>): void {
    const newResult: InterviewResult = {
        ...result,
        answeredOn: new Date().toISOString(),
        status: 'pending'
    };
    this.results.update(current => [newResult, ...current]);
  }
  
  approveSessionResults(sessionId: string): void {
    this.results.update(results => 
      results.map(r => r.sessionId === sessionId ? { ...r, status: 'approved' } : r)
    );
  }

  rejectSessionResults(sessionId: string): void {
    this.results.update(results => 
      results.map(r => r.sessionId === sessionId ? { ...r, status: 'rejected' } : r)
    );
  }

  // --- Persistence ---

  private loadFromLocalStorage(): void {
    try {
      const storedTemplates = localStorage.getItem(this.TEMPLATES_STORAGE_KEY);
      if (storedTemplates) {
        let parsedTemplates: InterviewTemplate[] = JSON.parse(storedTemplates);

        // Migration: Add 'type' property if it doesn't exist
        parsedTemplates = parsedTemplates.map(t => ({ ...t, type: t.type || 'general' }));

        // Ensure default templates always exist
        if (!parsedTemplates.find((t: InterviewTemplate) => t.id === 'template_default')) {
           parsedTemplates.push(initialDefaultTemplate);
        }
         if (!parsedTemplates.find((t: InterviewTemplate) => t.id === 'template_mid_devops')) {
           const fullstackIndex = parsedTemplates.findIndex(t => t.id === 'template_mid_fullstack');
           if (fullstackIndex !== -1) {
             parsedTemplates.splice(fullstackIndex + 1, 0, devOpsEngineerTemplate);
           } else {
             parsedTemplates.unshift(devOpsEngineerTemplate);
           }
        }
        if (!parsedTemplates.find((t: InterviewTemplate) => t.id === 'template_mid_fullstack')) {
           const seniorIndex = parsedTemplates.findIndex(t => t.id === 'template_senior_swe');
           if (seniorIndex !== -1) {
             parsedTemplates.splice(seniorIndex + 1, 0, midLevelFullStackTemplate);
           } else {
             parsedTemplates.unshift(midLevelFullStackTemplate);
           }
        }
        if (!parsedTemplates.find((t: InterviewTemplate) => t.id === 'template_junior_frontend')) {
           const fullstackIndex = parsedTemplates.findIndex(t => t.id === 'template_mid_fullstack');
           if (fullstackIndex !== -1) {
             parsedTemplates.splice(fullstackIndex + 1, 0, juniorFrontendDeveloperTemplate);
           } else {
             parsedTemplates.unshift(juniorFrontendDeveloperTemplate);
           }
        }
        if (!parsedTemplates.find((t: InterviewTemplate) => t.id === 'template_senior_swe')) {
           parsedTemplates.unshift(seniorSoftwareEngineerTemplate);
        }
        this.interviewTemplates.set(parsedTemplates);

      } else {
        this.interviewTemplates.set(INITIAL_TEMPLATES); // Load defaults if nothing is stored
      }

      const storedResults = localStorage.getItem(this.RESULTS_STORAGE_KEY);
      if (storedResults) {
        let results: InterviewResult[] = JSON.parse(storedResults);
        // Migration for existing results to add sessionId and status
        results = results.map(r => ({
          ...r,
          sessionId: r.sessionId || `session_${new Date(r.answeredOn).getTime()}`,
          status: r.status || 'approved' // Assume old results are approved
        }));
        this.results.set(results);
      }
    } catch (e) {
      console.error("Failed to load data from localStorage", e);
      this.interviewTemplates.set(INITIAL_TEMPLATES);
      this.results.set([]);
    }
  }

  private saveToLocalStorage(key: string, data: any): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error(`Failed to save data to localStorage (key: ${key})`, e);
    }
  }
  
  // DEPRECATED METHODS for old question model - can be removed later
  getQuestions(): InterviewQuestion[] { return []; }
  addQuestion(text: string): void {}
  updateQuestion(id: string, newText: string): void {}
  deleteQuestion(id: string): void {}
}