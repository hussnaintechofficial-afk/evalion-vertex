import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';
import { publicGuard } from './guards/public.guard';
import { LoginComponent } from './components/login/login.component';
import { CandidateDashboardComponent } from './components/candidate-dashboard/candidate-dashboard.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { LandingComponent } from './components/landing/landing.component';
import { SignupComponent } from './components/signup/signup.component';
import { CertificateComponent } from './components/certificate/certificate.component';

export const APP_ROUTES: Routes = [
  { path: 'landing', component: LandingComponent },
  { path: 'login', component: LoginComponent, canActivate: [publicGuard] },
  { path: 'signup', component: SignupComponent, canActivate: [publicGuard] },
  { 
    path: 'candidate', 
    component: CandidateDashboardComponent,
    canActivate: [authGuard] 
  },
  { 
    path: 'admin', 
    component: AdminDashboardComponent,
    canActivate: [authGuard]
  },
  { 
    path: 'certificate/:sessionId', 
    component: CertificateComponent,
    canActivate: [authGuard]
  },
  // Redirect to landing page by default
  { path: '', redirectTo: '/landing', pathMatch: 'full' },
  // Wildcard route for a 404 page or redirect
  { path: '**', redirectTo: '/landing' }
];