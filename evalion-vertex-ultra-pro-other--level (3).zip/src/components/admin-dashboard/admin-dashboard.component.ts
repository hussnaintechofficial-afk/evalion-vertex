import { ChangeDetectionStrategy, Component, computed, inject, signal, OnInit } from '@angular/core';
import { CommonModule, Location, DatePipe } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, User, UserRole } from '../../services/auth.service';
import { InterviewService, InterviewTemplate, InterviewResult, InterviewTemplateType } from '../../services/interview.service';
import { GeminiService } from '../../services/gemini.service';
import { ConfirmationDialogComponent } from '../shared/confirmation-dialog.component';
import { ThemeCustomizerComponent } from '../shared/theme-customizer.component';
import { HeaderComponent } from '../shared/header.component';
import { ThemeService } from '../../services/theme.service';

type AdminDashboardView = 'templates' | 'performance' | 'users' | 'theme-settings';

interface SessionGroup {
  sessionId: string;
  results: InterviewResult[];
  overallScore: number;
  status: 'pending' | 'approved' | 'rejected';
  jobTitle: string;
  date: string;
  userName: string;
  user: User | null;
}

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DatePipe, ConfirmationDialogComponent, ThemeCustomizerComponent, HeaderComponent],
  templateUrl: './admin-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminDashboardComponent implements OnInit {
  authService = inject(AuthService);
  interviewService = inject(InterviewService);
  geminiService = inject(GeminiService);
  themeService = inject(ThemeService);
  private router = inject(Router);
  private fb: FormBuilder = inject(FormBuilder);
  
  view = signal<AdminDashboardView>('templates');
  isLoadingView = signal(false);
  currentYear = new Date().getFullYear();
  isUserMenuOpen = signal(false);

  // --- Role-Based Access ---
  isSuperAdmin = computed(() => this.authService.currentUserRole() === 'super-admin');
  canManageTemplates = computed(() => {
    const role = this.authService.currentUserRole();
    return role === 'super-admin' || role === 'content-manager';
  });
  
  // --- Template Management State ---
  templates = signal<InterviewTemplate[]>([]);
  isGenerating = signal(false);
  generationError = signal<string | null>(null);
  expandedTemplateId = signal<string | null>(null);
  templateToDelete = signal<InterviewTemplate | null>(null);
  showLogoutConfirm = signal(false);

  templateForm = this.fb.group({
    jobTitle: ['', Validators.required],
    category: ['Software Engineering', Validators.required],
    experienceLevel: ['Senior', Validators.required],
    questionCount: [5, [Validators.required, Validators.min(1), Validators.max(10)]],
    type: ['technical' as InterviewTemplateType, Validators.required]
  });

  // --- Performance View State ---
  allResults = signal<InterviewResult[]>([]);
  expandedResultId = signal<string | null>(null);

  // Computed results now point directly to all results, as filters are removed.
  groupedSessions = computed<SessionGroup[]>(() => {
    const groups = new Map<string, SessionGroup>();
    const allUsers = this.authService.getAllUsers();
    
    this.interviewService.getResults().forEach(result => {
        if (!groups.has(result.sessionId)) {
            const user = allUsers.find(u => u.name === result.userName) || null;
            groups.set(result.sessionId, { 
                sessionId: result.sessionId,
                results: [], 
                overallScore: 0, 
                status: result.status, 
                jobTitle: result.jobTitle, 
                date: result.answeredOn,
                userName: result.userName,
                user: user
            });
        }
        groups.get(result.sessionId)!.results.push(result);
    });

    groups.forEach(group => {
        const total = group.results.reduce((sum, r) => sum + r.evaluation.score, 0);
        group.overallScore = total / group.results.length;
    });

    return Array.from(groups.values()).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });
  
  // --- Analytics for results ---
  filteredTotalSubmissions = computed(() => this.groupedSessions().length);
  filteredAverageScore = computed(() => {
    const sessions = this.groupedSessions();
    if (sessions.length === 0) return 0;
    const total = sessions.reduce((sum, r) => sum + r.overallScore, 0);
    return total / sessions.length;
  });

  // --- User Management State ---
  allUsers = signal<User[]>([]);
  userToToggleStatus = signal<User | null>(null); // For confirmation dialog
  showUserStatusConfirm = signal(false);
  sessionToUpdate = signal<{ session: SessionGroup, action: 'approve' | 'reject' } | null>(null);
  showSessionConfirm = signal(false);
  availableRoles: UserRole[] = ['candidate', 'content-manager', 'super-admin'];

  ngOnInit(): void {
    this.templates.set(this.interviewService.getInterviewTemplates());
    this.allResults.set(this.interviewService.getResults());
    this.allUsers.set(this.authService.getAllUsers()); // Fetch all users
  }

  handleLogout(confirmed: boolean): void {
    if (confirmed) {
      this.authService.logout();
    }
    this.showLogoutConfirm.set(false);
  }
  
  setView(newView: AdminDashboardView): void {
    if (this.view() === newView) { return; }

    this.isLoadingView.set(true);

    setTimeout(() => {
      this.view.set(newView);
      this.isLoadingView.set(false);
    }, 300);
  }

  async generateAndSaveTemplate(): Promise<void> {
    if (this.templateForm.invalid) {
      this.templateForm.markAllAsTouched();
      return;
    }
    
    this.isGenerating.set(true);
    this.generationError.set(null);
    const { jobTitle, category, experienceLevel, questionCount, type } = this.templateForm.value;

    const questions = await this.geminiService.generateInterviewQuestions(
      jobTitle!, category!, experienceLevel!, questionCount!
    );

    if (questions) {
      this.interviewService.addInterviewTemplate({
        jobTitle: jobTitle!,
        category: category!,
        experienceLevel: experienceLevel!,
        questions: questions,
        type: type!
      });
      this.templates.set(this.interviewService.getInterviewTemplates());
      this.templateForm.reset({ category: 'Software Engineering', experienceLevel: 'Senior', questionCount: 5, type: 'technical' });
    } else {
      this.generationError.set(this.geminiService.error() || 'An unknown error occurred during question generation.');
    }
    
    this.isGenerating.set(false);
  }

  confirmDeleteTemplate(template: InterviewTemplate): void {
    this.templateToDelete.set(template);
  }
  
  handleDelete(confirmed: boolean): void {
    if (confirmed && this.templateToDelete()) {
      this.interviewService.deleteInterviewTemplate(this.templateToDelete()!.id);
      this.templates.set(this.interviewService.getInterviewTemplates());
    }
    this.templateToDelete.set(null);
  }
  
  toggleTemplateExpansion(templateId: string): void {
    this.expandedTemplateId.update(current => (current === templateId ? null : templateId));
  }
  
  toggleResultExpansion(sessionId: string): void {
    this.expandedResultId.update(current => (current === sessionId ? null : sessionId));
  }
  
  confirmUpdateSession(session: SessionGroup, action: 'approve' | 'reject'): void {
    this.sessionToUpdate.set({ session, action });
    this.showSessionConfirm.set(true);
  }

  handleUpdateSession(confirmed: boolean): void {
    const update = this.sessionToUpdate();
    if (confirmed && update) {
      if (update.action === 'approve') {
        this.interviewService.approveSessionResults(update.session.sessionId);
      } else {
        this.interviewService.rejectSessionResults(update.session.sessionId);
      }
    }
    this.sessionToUpdate.set(null);
    this.showSessionConfirm.set(false);
  }
  
  viewCertificate(sessionId: string): void {
    this.router.navigate(['/certificate', sessionId]);
  }


  // --- User Management Methods ---
  confirmToggleUserStatus(user: User): void {
    this.userToToggleStatus.set(user);
    this.showUserStatusConfirm.set(true);
  }

  handleToggleUserStatus(confirmed: boolean): void {
    if (confirmed && this.userToToggleStatus()) {
      this.authService.toggleUserStatus(this.userToToggleStatus()!.id);
      this.allUsers.set(this.authService.getAllUsers()); // Refresh user list
    }
    this.userToToggleStatus.set(null);
    this.showUserStatusConfirm.set(false);
  }

  changeUserRole(userId: string, event: Event): void {
    const newRole = (event.target as HTMLSelectElement).value as UserRole;
    if (this.authService.updateUserRole(userId, newRole)) {
      this.allUsers.set(this.authService.getAllUsers()); // Refresh user list
    } else {
      // This will happen if a super admin tries to change their own role.
      // Revert the dropdown in the UI by refreshing the user list.
      alert("Role could not be changed. Super Admins cannot change their own role.");
      this.allUsers.set(this.authService.getAllUsers());
    }
  }
  
  // --- Styling Helpers ---
  getScoreColorClass(score: number): string {
    if (score >= 8) return 'text-emerald-400';
    if (score >= 5) return 'text-cyan-400';
    return 'text-purple-400';
  }
  
  getScoreGradientClass(score: number): string {
    if (score >= 8) return 'from-emerald-400 to-green-500';
    if (score >= 5) return 'from-cyan-400 to-blue-500';
    return 'from-purple-400 to-indigo-500';
  }
}