import { ChangeDetectionStrategy, Component, computed, inject, signal, effect, OnInit, AfterViewInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { CommonModule, Location, DOCUMENT, DatePipe } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { InterviewComponent } from '../interview/interview.component';
import { ChatbotComponent } from '../chatbot/chatbot.component';
import { AuthService, User } from '../../services/auth.service';
import { InterviewService, InterviewResult, InterviewTemplate } from '../../services/interview.service';
import { ConfirmationDialogComponent } from '../shared/confirmation-dialog.component';
import { ThemeService } from '../../services/theme.service';
import { ThemeCustomizerComponent } from '../shared/theme-customizer.component';
import { HeaderComponent } from '../shared/header.component';

declare var Chart: any;

type DashboardView = 'overview' | 'practice' | 'history' | 'profile' | 'theme-settings' | 'results-summary';

@Component({
  selector: 'app-candidate-dashboard',
  standalone: true,
  imports: [CommonModule, InterviewComponent, ChatbotComponent, DatePipe, ReactiveFormsModule, ConfirmationDialogComponent, ThemeCustomizerComponent, HeaderComponent],
  templateUrl: './candidate-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CandidateDashboardComponent implements OnInit, AfterViewInit, OnDestroy {
  authService = inject(AuthService);
  interviewService = inject(InterviewService);
  themeService = inject(ThemeService);
  private location = inject(Location);
  private fb: FormBuilder = inject(FormBuilder);
  private router: Router = inject(Router);

  @ViewChild('performanceChart', { static: false }) performanceChart!: ElementRef<HTMLCanvasElement>;
  private chartInstance: any;

  view = signal<DashboardView>('practice');
  isLoadingView = signal(false);
  pastResults = signal<InterviewResult[]>([]);
  expandedResult = signal<string | null>(null);

  availableTemplates = signal<InterviewTemplate[]>([]);
  isPracticing = signal(false);
  isUserMenuOpen = signal(false);

  // --- Filtering State ---
  jobTitleFilter = signal<string>('');
  categoryFilter = signal<string>('');
  experienceFilter = signal<string>('');
  typeFilter = signal<string>('');

  uniqueJobTitles = computed(() => [...new Set(this.availableTemplates().map(t => t.jobTitle))]);
  uniqueCategories = computed(() => [...new Set(this.availableTemplates().map(t => t.category))]);
  uniqueExperienceLevels = computed(() => [...new Set(this.availableTemplates().map(t => t.experienceLevel))]);
  uniqueTypes = computed(() => [...new Set(this.availableTemplates().map(t => t.type))]);

  filteredTemplates = computed(() => {
    const templates = this.availableTemplates();
    const jobTitle = this.jobTitleFilter();
    const category = this.categoryFilter();
    const experience = this.experienceFilter();
    const type = this.typeFilter();

    if (!jobTitle && !category && !experience && !type) {
      return templates;
    }

    return templates.filter(template => {
      const matchesJobTitle = !jobTitle || template.jobTitle === jobTitle;
      const matchesCategory = !category || template.category === category;
      const matchesExperience = !experience || template.experienceLevel === experience;
      const matchesType = !type || template.type === type;
      return matchesJobTitle && matchesCategory && matchesExperience && matchesType;
    });
  });

  completedCount = computed(() => this.pastResults().length);
  averageScore = computed(() => {
    const results = this.pastResults();
    if (results.length === 0) return 0;
    const total = results.reduce((sum, result) => sum + result.evaluation.score, 0);
    return total / results.length;
  });
  highestScore = computed(() => {
    const results = this.pastResults();
    if (results.length === 0) return 0;
    return Math.max(...results.map(r => r.evaluation.score));
  });

  showLogoutConfirm = signal(false);

  // --- Profile State ---
  profileForm = this.fb.group({
    name: ['', Validators.required],
    fatherName: [''],
    dob: [''],
    cnic: [''],
    mobile: [''],
    photoUrl: ['']
  });
  isEditingProfile = signal(false);
  profileUpdateStatus = signal<{ message: string, type: 'success' | 'error' } | null>(null);

  // --- Results Summary State ---
  lastCompletedSessionId = signal<string | null>(null);
  sessionResults = computed(() => {
      const sessionId = this.lastCompletedSessionId();
      if (!sessionId) return [];
      // Get the latest results for the session
      const user = this.authService.currentUser();
      const allUserResults = this.interviewService.getResults().filter(r => r.userName === user?.name);
      return allUserResults.filter(r => r.sessionId === sessionId);
  });
  sessionOverallScore = computed(() => {
      const results = this.sessionResults();
      if (results.length === 0) return 0;
      const total = results.reduce((sum, result) => sum + result.evaluation.score, 0);
      return total / results.length;
  });
  sessionVerdict = computed(() => {
      const score = this.sessionOverallScore();
      if (score >= 8) return { text: 'Passed', color: 'text-emerald-400' };
      if (score >= 5) return { text: 'Average', color: 'text-cyan-400' };
      return { text: 'Failed', color: 'text-purple-400' };
  });
  
  // --- History State ---
  groupedResults = computed(() => {
    const groups = new Map<string, { results: InterviewResult[], overallScore: number, status: string, jobTitle: string, date: string }>();
    this.pastResults().forEach(result => {
        if (!groups.has(result.sessionId)) {
            groups.set(result.sessionId, { results: [], overallScore: 0, status: result.status, jobTitle: result.jobTitle, date: result.answeredOn });
        }
        groups.get(result.sessionId)!.results.push(result);
    });
    groups.forEach(group => {
        const total = group.results.reduce((sum, r) => sum + r.evaluation.score, 0);
        group.overallScore = total / group.results.length;
    });
    return Array.from(groups.values()).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });


  constructor() {
     effect(() => {
      // Re-render chart if theme, results, or loading state change
      this.pastResults();
      this.themeService.mode();
      const isLoading = this.isLoadingView();

      if (!isLoading && this.view() === 'overview' && this.performanceChart?.nativeElement) {
        this.destroyChart();
        this.createChart();
      }
    });

    // Populate profile form when user data is available
    effect(() => {
      const user = this.authService.currentUser();
      if (user) {
        this.profileForm.patchValue({
          name: user.name,
          fatherName: user.fatherName,
          dob: user.dob,
          cnic: user.cnic,
          mobile: user.mobile,
          photoUrl: user.photoUrl,
        });
      }
    });
  }
  
  ngOnInit(): void {
    const user = this.authService.currentUser();
    this.pastResults.set(this.interviewService.getResults().filter(r => r.userName === user?.name));
    this.availableTemplates.set(this.interviewService.getInterviewTemplates());
  }

  ngAfterViewInit(): void {
    if (this.view() === 'overview') {
       this.createChart();
    }
  }

  ngOnDestroy(): void {
    this.destroyChart();
  }
  
  startPractice(templateId: string): void {
    if (this.interviewService.startInterviewSession(templateId)) {
        this.isPracticing.set(true);
    } else {
        alert("Could not start interview. The selected template has no questions.");
    }
  }

  handleInterviewCompletion(sessionId: string): void {
    const user = this.authService.currentUser();
    this.pastResults.set(this.interviewService.getResults().filter(r => r.userName === user?.name)); // Refresh results
    this.lastCompletedSessionId.set(sessionId);
    this.isPracticing.set(false);
    this.setView('results-summary');
  }

  private destroyChart(): void {
    if (this.chartInstance) {
      this.chartInstance.destroy();
      this.chartInstance = null;
    }
  }

  private createChart(): void {
    if (!this.performanceChart?.nativeElement || this.pastResults().length === 0) return;
    
    setTimeout(() => {
      if (!this.performanceChart?.nativeElement) return;
      const ctx = this.performanceChart.nativeElement.getContext('2d');
      if (!ctx) return;
      
      const isLightTheme = this.themeService.mode() === 'light';
      const gridColor = isLightTheme ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255, 255, 255, 0.1)';
      const labelColor = isLightTheme ? '#374151' : '#E5E7EB';
      
      const reversedResults = [...this.pastResults()].reverse();
      const labels = reversedResults.map((_, i) => `Attempt ${i + 1}`);
      const data = reversedResults.map(r => r.evaluation.score);

      const gradient = ctx.createLinearGradient(0, 0, 0, 400);
      gradient.addColorStop(0, 'rgba(34, 211, 238, 0.6)');
      gradient.addColorStop(1, 'rgba(139, 92, 246, 0.1)');

      this.chartInstance = new Chart(ctx, {
        type: 'line', data: { labels: labels, datasets: [{ data: data, backgroundColor: gradient, borderColor: '#22D3EE', borderWidth: 2, pointBackgroundColor: '#FFFFFF', pointBorderColor: '#22D3EE', pointHoverBackgroundColor: '#22D3EE', pointHoverBorderColor: '#FFFFFF', tension: 0.4, fill: true, }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, max: 10, grid: { color: gridColor }, ticks: { color: labelColor } }, x: { grid: { display: false }, ticks: { color: labelColor } } } }
      });
    }, 10);
  }

  confirmLogout(): void {
    this.showLogoutConfirm.set(true);
    this.isUserMenuOpen.set(false);
  }
  
  logout(confirmed: boolean): void {
    if(confirmed) {
      this.authService.logout();
    }
    this.showLogoutConfirm.set(false);
  }

  goBack(): void {
    if (this.isPracticing()) {
      this.isPracticing.set(false);
    } else {
      this.location.back();
    }
  }
  
  setView(newView: DashboardView): void {
    this.isUserMenuOpen.set(false);
    if (this.view() === newView) { return; }
    
    this.isLoadingView.set(true);
    this.isPracticing.set(false);
    this.isEditingProfile.set(false);

    // Short delay to show loading animation and improve perceived performance
    setTimeout(() => {
      this.view.set(newView);
      this.isLoadingView.set(false);
    }, 300);
  }

  goBackToMainView(): void {
    this.setView('practice');
  }
  
  toggleResultExpansion(sessionId: string): void {
    this.expandedResult.update(current => current === sessionId ? null : sessionId);
  }
  
  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        this.profileForm.patchValue({ photoUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  }

  saveProfile(): void {
    if (this.profileForm.invalid) {
      this.profileUpdateStatus.set({ message: '