import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, Validators, ValidatorFn } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { HeaderComponent } from '../shared/header.component';

// Custom validator to check if passwords match
export const passwordsMatchValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const password = control.get('password');
  const confirmPassword = control.get('confirmPassword');
  
  if (password && confirmPassword && password.value !== confirmPassword.value) {
    return { passwordsMismatch: true };
  }
  
  return null;
};

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, HeaderComponent],
  templateUrl: './signup.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SignupComponent {
  private fb: FormBuilder = inject(FormBuilder);
  private authService = inject(AuthService);
  private router: Router = inject(Router);
  
  signupError = signal<string | null>(null);
  showPassword = signal(false);
  showConfirmPassword = signal(false);
  photoPreview = signal<string | null>(null);

  signupForm = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]],
    confirmPassword: ['', Validators.required],
    fatherName: [''],
    dob: [''],
    cnic: ['', [Validators.pattern(/^\d{5}-\d{7}-\d{1}$/)]], // Optional but needs to match format XXXXX-XXXXXXX-X
    mobile: ['', [Validators.pattern(/^\+?\d{10,12}$/)]], // Optional but needs to be a valid phone number
    photoUrl: [''],
    agreeToTerms: [false, Validators.requiredTrue] // New: Terms and Privacy Policy agreement
  }, { validators: passwordsMatchValidator });

  constructor() {
    if (this.authService.isAuthenticated()) {
        const role = this.authService.currentUserRole();
        this.router.navigate([role ? `/${role}` : '/candidate']);
    }
  }

  togglePasswordVisibility(): void {
    this.showPassword.update(value => !value);
  }
  
  toggleConfirmPasswordVisibility(): void {
    this.showConfirmPassword.update(value => !value);
  }
  
  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        this.photoPreview.set(result);
        this.signupForm.patchValue({ photoUrl: result });
      };
      reader.readAsDataURL(file);
    }
  }

  onSubmit(): void {
    if (this.signupForm.invalid) {
      // Mark all fields as touched to show validation errors
      this.signupForm.markAllAsTouched();
      this.signupError.set('Please correct the errors in the form.');
      return;
    }

    this.signupError.set(null);
    
    // We can safely cast as we've checked for validity.
    // Exclude 'confirmPassword' and 'agreeToTerms' from the data sent to auth service.
    const { confirmPassword, agreeToTerms, ...userData } = this.signupForm.value as any;
    
    const result = this.authService.signUp(userData);

    if (!result.success) {
      this.signupError.set(result.message);
    }
    // On success, the auth service handles navigation to the candidate dashboard.
  }
}