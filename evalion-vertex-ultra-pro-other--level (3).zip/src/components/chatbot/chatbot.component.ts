import { ChangeDetectionStrategy, Component, signal, inject, ViewChild, ElementRef, effect, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService, ChatMode } from '../../services/gemini.service';

interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
  isTyping?: boolean;
}

@Component({
  selector: 'app-chatbot',
  standalone: true,
  templateUrl: './chatbot.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule]
})
export class ChatbotComponent implements AfterViewInit, OnDestroy {
  geminiService = inject(GeminiService);

  @ViewChild('chatHistory', { static: false }) chatHistory!: ElementRef<HTMLDivElement>;

  messages = signal<ChatMessage[]>([
    { sender: 'ai', text: "Hello! I'm Evalion's Assistant. How can I help you prepare for your interview today?", isTyping: false }
  ]);
  chatInput = signal('');
  isLoading = signal(false);
  isChatOpen = signal(false);
  chatMode = signal<ChatMode>('standard');

  private resizeObserver: ResizeObserver | null = null;

  constructor() {
    effect(() => {
      this.messages(); // Trigger when messages change
      if (this.isChatOpen()) { // Only scroll if chat is open
        // Use queueMicrotask to ensure the DOM has updated before scrolling
        queueMicrotask(() => this.scrollToBottom());
      }
    });
  }

  ngAfterViewInit(): void {
    if (this.chatHistory?.nativeElement) {
      this.resizeObserver = new ResizeObserver(() => {
        if (this.isChatOpen()) {
          this.scrollToBottom();
        }
      });
      this.resizeObserver.observe(this.chatHistory.nativeElement);
    }
  }

  ngOnDestroy(): void {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
  }
  
  setChatMode(mode: ChatMode): void {
    this.chatMode.set(mode);
  }

  toggleChat(): void {
    this.isChatOpen.update(open => !open);
  }

  async sendMessage(): Promise<void> {
    const userMessage = this.chatInput().trim();
    if (!userMessage) return;

    this.messages.update(msgs => [...msgs, { sender: 'user', text: userMessage }]);
    this.chatInput.set('');
    this.isLoading.set(true);
    this.messages.update(msgs => [...msgs, { sender: 'ai', text: '', isTyping: true }]);
    
    try {
      let fullAiResponse = '';
      const messageIndex = this.messages().length - 1;

      for await (const chunk of this.geminiService.chatWithAI(userMessage, this.chatMode())) {
        fullAiResponse += chunk;
        this.messages.update(msgs => {
          const updatedMsgs = [...msgs];
          if (updatedMsgs[messageIndex]) {
            updatedMsgs[messageIndex].text = fullAiResponse;
          }
          return updatedMsgs;
        });
      }
      this.messages.update(msgs => {
        const updatedMsgs = [...msgs];
        if (updatedMsgs[messageIndex]) {
          updatedMsgs[messageIndex].isTyping = false;
        }
        return updatedMsgs;
      });

    } catch (error) {
      console.error('Chatbot message error:', error);
      this.messages.update(msgs => {
        const updatedMsgs = [...msgs];
        updatedMsgs[updatedMsgs.length - 1] = {
          sender: 'ai',
          text: "I'm sorry, I encountered an error communicating with the AI. Please try again.",
          isTyping: false
        };
        return updatedMsgs;
      });
    } finally {
      this.isLoading.set(false);
    }
  }

  private scrollToBottom(): void {
    if (this.chatHistory?.nativeElement) {
      try {
        this.chatHistory.nativeElement.scroll({
          top: this.chatHistory.nativeElement.scrollHeight,
          behavior: 'smooth'
        });
      } catch (err) {
        console.warn('Could not scroll chat history:', err);
      }
    }
  }
}