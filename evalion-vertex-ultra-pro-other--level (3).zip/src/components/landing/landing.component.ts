import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { Router } from '@angular/router';
import { HeaderComponent } from '../shared/header.component';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, HeaderComponent],
  templateUrl: './landing.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LandingComponent implements OnInit {
  private router: Router = inject(Router);
  private document: Document = inject(DOCUMENT);
  currentYear = new Date().getFullYear();
  flowingParticles = signal<any[]>([]);

  ngOnInit(): void {
    this.generateFlowingParticles();
  }

  generateFlowingParticles(): void {
    const particles = Array.from({ length: 50 }).map(() => ({
      left: `${Math.random() * 100}%`,
      animationDuration: `${Math.random() * 10 + 5}s`,
      animationDelay: `${Math.random() * 10}s`,
      opacity: Math.random() * 0.3 + 0.1, // 0.1 to 0.4 for subtlety
      width: `${Math.random() * 1.5 + 0.5}px`, // 0.5px to 2px wide
      height: `${Math.random() * 30 + 20}px`, // 20px to 50px long
    }));
    this.flowingParticles.set(particles);
  }

  navigateToLogin(): void {
    this.router.navigate(['/login']);
  }
  
  handleDownloadClick(event: MouseEvent): void {
    event.preventDefault(); // Prevent the default link navigation
    const pkg = 'com.evalion.vertexultrapro';
    const playStoreUrl = `https://play.google.com/store/apps/details?id=${pkg}`;
    const marketUrl = `market://details?id=${pkg}`;
    
    const window = this.document.defaultView;
    if (!window) return;

    try {
      window.location.href = marketUrl;
      setTimeout(() => {
        window.open(playStoreUrl, '_blank');
      }, 800);
    } catch(e) {
      window.open(playStoreUrl, '_blank');
    }
  }
}