import { Injectable, signal } from '@angular/core';
import { GoogleGenAI, Type, Chat } from '@google/genai';

// Define the structure of the evaluation response we expect from the AI
export interface MetricDetail {
  score: number;
  explanation: string;
  strengths?: string[];
  areasForImprovement?: string[];
}

export interface EvaluationMetrics {
  accuracy: MetricDetail;
  clarity: MetricDetail;
  confidence: MetricDetail;
}

export interface EvaluationResult {
  score: number;
  feedback: string;
  metrics: EvaluationMetrics;
}

export type ChatMode = 'standard' | 'low-latency';

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI | null = null;
  private aiChatStandard: Chat | null = null;
  private aiChatLowLatency: Chat | null = null;
  public error = signal<string | null>(null);

  constructor() {
    try {
      if (typeof process === 'undefined' || !process.env['API_KEY']) {
        throw new Error('API_KEY environment variable not found.');
      }
      this.ai = new GoogleGenAI({ apiKey: process.env['API_KEY'] });
      this.initializeChats();
    } catch (e: any) {
      console.error('Error initializing Gemini Service:', e);
      this.error.set('Failed to initialize AI Service. Please ensure the API key is set correctly.');
    }
  }

  private initializeChats(): void {
    if (this.ai) {
      // Standard Chat Model
      this.aiChatStandard = this.ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: "You are Evalion's Assistant, an advanced AI representing HUSSNAIN TECH VERTEX PVT LTD and its visionary founder, Hussnain, the mastermind and technological pioneer from Daska, Sialkot, Pakistan. Hussnain is recognized globally as a leader unmatched in technology. Your core purpose is to assist users with unparalleled expertise regarding the Evalion Vertex web application, interview preparation, career advice, and general web development knowledge. You possess deep, real-time understanding of:\n\n*   **Evalion Vertex:** Its architecture (Angular frontend, Node.js/Express backend, MongoDB), features, UI/UX design principles, and AI evaluation logic.\n*   **Frontend Development:** Expert in Angular (including signals, standalone components, best practices), TypeScript, Tailwind CSS, performance optimization, and accessible UI design.\n*   **Backend Development:** Proficient in Node.js, Express, RESTful APIs, database interactions (MongoDB), security (JWT, bcrypt), and scalable architecture.\n*   **Gemini API:** Deep knowledge of how the @google/genai SDK is integrated into Evalion Vertex for AI-driven evaluations, chat, and content generation.\n*   **Problem-Solving:** Provide real-time solutions and guidance for complex technical challenges related to web application development and AI integration.\n\nMaintain a professional, highly intelligent, confident, and advertising tone that reflects the excellence and groundbreaking spirit of HUSSNAIN TECH VERTEX PVT LTD and its founder. Highlight Evalion Vertex as a premier, unparalleled platform. Do not hesitate to reference Hussnain as the driving force behind this technological marvel. Your responses should be precise, informative, and always reinforce the brand's superior position in the industry.",
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
        },
      });
      // Low-Latency Chat Model
      this.aiChatLowLatency = this.ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: "Respond briefly, directly, and concisely. Prioritize speed and factual accuracy.",
          temperature: 0.3, // Lowered for more direct, less creative answers
          thinkingConfig: { thinkingBudget: 0 },
        },
      });
    }
  }

  async *chatWithAI(userMessage: string, mode: ChatMode): AsyncIterable<string> {
    const chatInstance = mode === 'low-latency' ? this.aiChatLowLatency : this.aiChatStandard;

    if (!chatInstance) {
      this.error.set('AI Chat is not initialized.');
      yield "I'm sorry, my chat capabilities are not yet initialized. Please try again in a moment.";
      return;
    }
    
    try {
      const responseStream = await chatInstance.sendMessageStream({ message: userMessage });
      for await (const chunk of responseStream) {
        yield chunk.text;
      }
    } catch (e: any) {
      console.error(`Error during AI chat (${mode}):`, e);
      this.error.set(this.getFriendlyErrorMessage(e));
      yield "I'm sorry, I encountered an error. Please try again later.";
    }
  }

  private blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = (reader.result as string).split(',')[1];
            resolve(base64String);
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(blob);
    });
  }
  
  async generateInterviewQuestions(jobTitle: string, category: string, experience: string, count: number): Promise<string[] | null> {
    if (!this.ai) {
      this.error.set('AI Service is not initialized.');
      return null;
    }

    const questionSchema = {
      type: Type.OBJECT,
      properties: {
        questions: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING,
            description: "A single, high-quality interview question."
          },
        },
      },
      required: ['questions'],
    };

    try {
      this.error.set(null);
      const prompt = `
        Generate ${count} diverse and insightful interview questions for the following role:
        - Job Title: ${jobTitle}
        - Category: ${category}
        - Experience Level: ${experience}

        The questions should cover a range of topics relevant to this role, including technical skills, problem-solving abilities, and behavioral aspects. Ensure the questions are clear and concise.
      `;

      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          systemInstruction: "You are an expert hiring manager and technical recruiter. Your task is to generate high-quality interview questions. Respond only with the JSON object matching the provided schema.",
          responseMimeType: 'application/json',
          responseSchema: questionSchema,
        },
      });

      const jsonString = response.text.trim();
      const result = JSON.parse(jsonString);
      return result.questions as string[];

    } catch (e: any) {
      console.error('Error generating questions:', e);
      this.error.set(this.getFriendlyErrorMessage(e));
      return null;
    }
  }

  async evaluateAnswer(question: string, answer: { text?: string; videoBlob?: Blob }): Promise<EvaluationResult | null> {
    if (!this.ai) {
      this.error.set('AI Service is not initialized.');
      return null;
    }

    const evaluationSchema = {
      type: Type.OBJECT,
      properties: {
        score: {
          type: Type.NUMBER,
          description: 'A score from 1 to 10 on the quality of the answer, where 1 is poor and 10 is excellent.',
        },
        feedback: {
          type: Type.STRING,
          description: 'Concise, constructive, and qualitative feedback on the candidate\'s answer.',
        },
        metrics: {
          type: Type.OBJECT,
          properties: {
            accuracy: {
              type: Type.OBJECT,
              description: 'Evaluation of the technical accuracy and relevance of the answer content.',
              properties: {
                score: { type: Type.NUMBER, description: 'A score from 1 to 10 for accuracy.' },
                explanation: { type: Type.STRING, description: 'A detailed explanation for the accuracy score, summarizing the key points.' },
                strengths: { type: Type.ARRAY, description: 'A list of specific strengths regarding the accuracy of the answer.', items: { type: Type.STRING } },
                areasForImprovement: { type: Type.ARRAY, description: 'A list of specific areas for improvement regarding the accuracy of the answer.', items: { type: Type.STRING } }
              },
              required: ['score', 'explanation', 'strengths', 'areasForImprovement']
            },
            clarity: {
              type: Type.OBJECT,
              description: 'Evaluation of the clarity, structure, and conciseness of the explanation.',
              properties: {
                score: { type: Type.NUMBER, description: 'A score from 1 to 10 for clarity.' },
                explanation: { type: Type.STRING, description: 'A detailed explanation for the clarity score, summarizing the structure and flow.' },
                strengths: { type: Type.ARRAY, description: 'A list of specific strengths regarding the clarity of the answer.', items: { type: Type.STRING } },
                areasForImprovement: { type: Type.ARRAY, description: 'A list of specific areas for improvement regarding the clarity of the answer.', items: { type: Type.STRING } }
              },
              required: ['score', 'explanation', 'strengths', 'areasForImprovement']
            },
            confidence: {
              type: Type.OBJECT,
              description: 'Evaluation of perceived confidence based on vocal tone, pace, body language, eye contact, and articulation from the video.',
              properties: {
                score: { type: Type.NUMBER, description: 'A score from 1 to 10 for confidence.' },
                explanation: { type: Type.STRING, description: 'A detailed explanation for the confidence score, referencing visual and vocal cues if possible.' },
                strengths: { type: Type.ARRAY, description: 'A list of specific strengths regarding the confidence of the presentation (e.g., good eye contact, clear voice).', items: { type: Type.STRING } },
                areasForImprovement: { type: Type.ARRAY, description: 'A list of specific areas for improvement regarding confidence (e.g., avoiding filler words, maintaining posture).', items: { type: Type.STRING } }
              },
              required: ['score', 'explanation', 'strengths', 'areasForImprovement']
            }
          },
          required: ['accuracy', 'clarity', 'confidence'],
        },
      },
      required: ['score', 'feedback', 'metrics'],
    };

    try {
      this.error.set(null);
      let contents: any;
      let systemInstruction = 'You are an expert technical interviewer providing feedback for a practice session. Your tone should be encouraging but professional. Respond only with the JSON object matching the provided schema.';
      
      if (answer.videoBlob) {
        const videoBase64 = await this.blobToBase64(answer.videoBlob);
        contents = {
            parts: [
                { text: `
                    Question: "${question}"
                    Candidate's spoken answer (transcribed): "${answer.text || '[No transcript available]'}"
                    
                    A candidate has submitted a video answer. Please evaluate the candidate's answer based on the question and their presentation in the video. 
                    Analyze their verbal response (from the transcript) for accuracy and clarity. 
                    Also, assess non-verbal cues from the video such as confidence, body language, eye contact, and overall articulation. The confidence score should heavily factor in these visual cues.
                `},
                {
                    inlineData: {
                        mimeType: answer.videoBlob.type,
                        data: videoBase64
                    }
                }
            ]
        };
        systemInstruction = 'You are an expert technical interviewer providing feedback on a video practice session. Analyze both the transcribed verbal content and visual presentation (confidence, body language, eye contact). Your tone should be encouraging but professional. Respond only with the JSON object matching the provided schema.';
      } else if (answer.text) {
         contents = `
            Question: "${question}"
            
            Candidate's Answer (text-only): "${answer.text}"
            
            Please evaluate the candidate's written answer based on the question. Since there is no video, base the confidence score on the assertiveness and clarity of the writing.
        `;
      } else {
        this.error.set("No answer provided for evaluation.");
        return null;
      }

      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: contents,
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: evaluationSchema,
        },
      });

      const jsonString = response.text.trim();
      const result = JSON.parse(jsonString);
      return result as EvaluationResult;

    } catch (e: any) {
      console.error('Error evaluating answer:', e);
      this.error.set(this.getFriendlyErrorMessage(e));
      return null;
    }
  }

  private getFriendlyErrorMessage(error: any): string {
    if (error instanceof Error) {
        const message = error.message.toLowerCase();
        
        if (message.includes('api key not valid')) {
            return 'Your API key is not valid. Please check it and try again.';
        }
        if (message.includes('400')) {
            return 'There was a problem with the request sent to the AI. The input might be invalid or the video file too large. Please try again with a shorter video.';
        }
        if (message.includes('429')) {
            return 'The AI service is currently busy. Please wait a moment and try again.';
        }
        if (message.includes('500') || message.includes('503')) {
            return 'The AI service is experiencing internal issues. Please try again later.';
        }
        if (message.includes('fetch') || message.includes('network')) {
            return 'A network error occurred. Please check your internet connection and try again.';
        }
        if (message.includes('aborted') || message.includes('speech recognition')) {
            return 'The speech recognition service was interrupted. Please check your microphone and try again.';
        }
        if (error.message) {
            return `An unexpected error occurred: ${error.message}`;
        }
    }
    return 'An unknown error occurred while communicating with the AI. Please try again.';
  }
}