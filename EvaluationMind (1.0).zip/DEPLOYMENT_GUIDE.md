# EVALUATIONMIND OS - PRODUCTION DEPLOYMENT GUIDE

**Document Version:** 1.0  
**Last Updated:** January 28, 2025  
**Status:** CRITICAL - READ BEFORE DEPLOYMENT

---

## TABLE OF CONTENTS

1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Environment Setup](#environment-setup)
3. [Database Migration](#database-migration)
4. [Docker Deployment](#docker-deployment)
5. [Kubernetes Deployment](#kubernetes-deployment)
6. [Health Checks & Monitoring](#health-checks--monitoring)
7. [Security Hardening](#security-hardening)
8. [Rollback Procedures](#rollback-procedures)
9. [Post-Deployment Verification](#post-deployment-verification)
10. [Troubleshooting](#troubleshooting)

---

## PRE-DEPLOYMENT CHECKLIST

### Infrastructure Requirements
- [ ] Domain name acquired and DNS configured
- [ ] SSL/TLS certificates obtained (Let's Encrypt or commercial)
- [ ] Cloud provider account setup (AWS/GCP/Azure)
- [ ] Load balancer configured
- [ ] Auto-scaling policies defined
- [ ] Backup strategy implemented
- [ ] CDN configured (CloudFront/Cloudflare)
- [ ] DDoS protection enabled (WAF)
- [ ] VPC/Network security groups configured
- [ ] Database replicas configured (for redundancy)

### Application Requirements
- [ ] All environment variables documented
- [ ] API endpoints fully implemented
- [ ] Database schema finalized
- [ ] Authentication fully working
- [ ] Error handling comprehensive
- [ ] Logging configured (ELK/CloudWatch)
- [ ] Rate limiting implemented
- [ ] CORS properly configured
- [ ] Security headers set
- [ ] All tests passing (unit, integration, e2e)

### Code Quality
- [ ] Code review completed
- [ ] Security scan passed (OWASP)
- [ ] Performance audit done (Lighthouse > 90)
- [ ] Dependency vulnerabilities resolved
- [ ] No console errors or warnings
- [ ] TypeScript strict mode enabled
- [ ] Linting rules enforced
- [ ] Code coverage > 80%

### Operations Requirements
- [ ] Runbook documented
- [ ] On-call rotation established
- [ ] Incident response plan ready
- [ ] Monitoring dashboards created
- [ ] Alert thresholds configured
- [ ] Log aggregation tested
- [ ] Backup/restore tested
- [ ] Disaster recovery plan documented
- [ ] Team trained on deployment process
- [ ] Communication plan prepared

---

## ENVIRONMENT SETUP

### Step 1: Configure Environment Variables

```bash
# SSH into production server
ssh deploy@your-production-server.com

# Create environment file
cd /opt/evalion-mind
nano .env.production

# Copy content from .env.example and set production values
# DO NOT use development values!

# Important variables to customize:
# - JWT_SECRET (generate: openssl rand -base64 32)
# - DATABASE_URL (production database)
# - REDIS_URL (production Redis)
# - STRIPE_SECRET_KEY (production key)
# - SENTRY_DSN (production DSN)
# - API domain and CORS origins
```

### Step 2: Verify Environment Variables

```bash
# Check all required variables are set
cat .env.production | grep -E "^[A-Z_]+" | sort

# Validate critical variables
test -z "$JWT_SECRET" && echo "ERROR: JWT_SECRET not set" || echo "✓ JWT_SECRET set"
test -z "$DATABASE_URL" && echo "ERROR: DATABASE_URL not set" || echo "✓ DATABASE_URL set"
test -z "$REDIS_URL" && echo "ERROR: REDIS_URL not set" || echo "✓ REDIS_URL set"
```

### Step 3: Create Production Database

```bash
# Connect to production PostgreSQL
psql postgresql://admin@prod-db.example.com/postgres

# Create database and user
CREATE DATABASE evalion_prod OWNER evalion_prod_user;
GRANT ALL PRIVILEGES ON DATABASE evalion_prod TO evalion_prod_user;

# Exit
\q

# Run migrations
npm run migrate:prod
```

### Step 4: Setup Redis

```bash
# Ensure Redis is running and accessible
redis-cli -h prod-redis.example.com ping
# Should return: PONG

# Test authentication
redis-cli -h prod-redis.example.com -a your_redis_password ping
```

---

## DATABASE MIGRATION

### Step 1: Backup Production Database

```bash
# Create backup before any migration
pg_dump \
  postgresql://evalion_prod_user:password@prod-db.example.com/evalion_prod \
  > backup_$(date +%Y%m%d_%H%M%S).sql

# Verify backup
ls -lh backup_*.sql
```

### Step 2: Run Database Migrations

```bash
# Set environment to production
export NODE_ENV=production
export DATABASE_URL="postgresql://evalion_prod_user:password@prod-db.example.com/evalion_prod"

# Run migrations (in order)
npm run db:migrate:01-init
npm run db:migrate:02-users
npm run db:migrate:03-recruitment
npm run db:migrate:04-interviews
npm run db:migrate:05-reports

# Verify migrations
psql $DATABASE_URL -c "\dt"  # List all tables
```

### Step 3: Seed Initial Data (if needed)

```bash
npm run db:seed
# This creates:
# - Admin user
# - Default pipeline stages
# - System configuration
```

### Step 4: Verify Database Integrity

```bash
# Check for orphaned records
psql $DATABASE_URL < scripts/verify-integrity.sql

# Run consistency checks
npm run db:validate
```

---

## DOCKER DEPLOYMENT

### Step 1: Build Docker Image

```bash
# Build production image
docker build \
  --target runtime \
  -t evalion-mind:1.0.24 \
  -t evalion-mind:latest \
  .

# Tag for registry
docker tag evalion-mind:latest your-registry.azurecr.io/evalion-mind:1.0.24
docker tag evalion-mind:latest your-registry.azurecr.io/evalion-mind:latest

# Push to registry
docker push your-registry.azurecr.io/evalion-mind:1.0.24
docker push your-registry.azurecr.io/evalion-mind:latest

# Verify
docker images | grep evalion-mind
```

### Step 2: Run Container

```bash
# Pull latest image
docker pull your-registry.azurecr.io/evalion-mind:latest

# Run container
docker run -d \
  --name evalion-mind-prod \
  --restart always \
  -p 3000:3000 \
  --env-file /opt/evalion-mind/.env.production \
  -v /opt/evalion-mind/logs:/app/logs \
  -v /opt/evalion-mind/uploads:/app/uploads \
  your-registry.azurecr.io/evalion-mind:latest

# Verify container is running
docker ps | grep evalion-mind-prod
```

### Step 3: Setup Reverse Proxy (Nginx)

```nginx
# /etc/nginx/sites-available/evalion-mind

upstream evalion_backend {
    server 127.0.0.1:3000;
    keepalive 64;
}

server {
    listen 80;
    listen [::]:80;
    server_name evalion-mind.os www.evalion-mind.os;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name evalion-mind.os www.evalion-mind.os;

    # SSL Certificates
    ssl_certificate /etc/letsencrypt/live/evalion-mind.os/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/evalion-mind.os/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;

    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=api_limit:10m rate=10r/s;
    limit_req zone=api_limit burst=20 nodelay;

    # Proxy to backend
    location / {
        proxy_pass http://evalion_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # WebSocket support
    location /ws {
        proxy_pass http://evalion_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        
        # WebSocket timeouts (longer)
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }

    # Static files (if serving frontend from same server)
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

### Step 4: Enable Nginx Configuration

```bash
# Check configuration syntax
sudo nginx -t

# Create symlink to enabled sites
sudo ln -s /etc/nginx/sites-available/evalion-mind /etc/nginx/sites-enabled/

# Reload Nginx
sudo systemctl reload nginx

# Verify
sudo systemctl status nginx
```

---

## KUBERNETES DEPLOYMENT

### Step 1: Create Kubernetes Manifests

```bash
mkdir -p k8s/overlays/prod
mkdir -p k8s/base
```

### Step 2: Base Deployment

```yaml
# k8s/base/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: evalion-mind
  namespace: evalion
spec:
  replicas: 3
  selector:
    matchLabels:
      app: evalion-mind
  template:
    metadata:
      labels:
        app: evalion-mind
    spec:
      containers:
      - name: evalion-mind
        image: your-registry.azurecr.io/evalion-mind:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 3000
          name: http
        env:
        - name: NODE_ENV
          value: "production"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: evalion-secrets
              key: database-url
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: evalion-secrets
              key: redis-url
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: evalion-secrets
              key: jwt-secret
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 5
```

### Step 3: Deploy to Kubernetes

```bash
# Create namespace
kubectl create namespace evalion

# Create secrets
kubectl create secret generic evalion-secrets \
  --from-literal=database-url=$DATABASE_URL \
  --from-literal=redis-url=$REDIS_URL \
  --from-literal=jwt-secret=$JWT_SECRET \
  -n evalion

# Apply manifests
kubectl apply -f k8s/base/ -n evalion
kubectl apply -f k8s/overlays/prod/ -n evalion

# Verify deployment
kubectl get deployment -n evalion
kubectl get pods -n evalion
kubectl describe deployment evalion-mind -n evalion
```

### Step 4: Setup Auto-scaling

```yaml
# k8s/base/hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: evalion-mind-hpa
  namespace: evalion
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: evalion-mind
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

---

## HEALTH CHECKS & MONITORING

### Step 1: Verify Application Health

```bash
# Check if application is responding
curl http://localhost:3000/health
# Expected response: {"status":"ok"}

# Check database connection
curl http://localhost:3000/health/db
# Expected response: {"database":"connected"}

# Check Redis connection
curl http://localhost:3000/health/redis
# Expected response: {"redis":"connected"}
```

### Step 2: Setup Monitoring (Prometheus)

```yaml
# prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'evalion-mind'
    static_configs:
      - targets: ['localhost:3000']
    metrics_path: '/metrics'
```

### Step 3: Setup Alerting (Grafana)

```bash
# Access Grafana dashboard
# Create alerts for:
# - Error rate > 1%
# - Response time > 1000ms
# - CPU > 80%
# - Memory > 85%
# - Database connection failures
```

### Step 4: Setup Error Tracking (Sentry)

```bash
# Configure Sentry DSN
# Monitor errors in real-time
# Set up notifications for critical errors
```

---

## SECURITY HARDENING

### Step 1: Enable Firewall

```bash
# UFW (Ubuntu)
sudo ufw enable
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 3000/tcp  # For testing only, remove in production

# Verify rules
sudo ufw status
```

### Step 2: Setup Fail2Ban

```bash
sudo apt-get install fail2ban

# Configure
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
sudo nano /etc/fail2ban/jail.local

# Set: bantime = 3600, findtime = 600, maxretry = 5

sudo systemctl restart fail2ban
```

### Step 3: Enable SSL/TLS

```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-nginx

# Get certificate
sudo certbot certonly --nginx -d evalion-mind.os

# Auto-renewal
sudo systemctl enable certbot.timer
```

### Step 4: Security Headers Configuration

```bash
# Verify headers are set
curl -I https://evalion-mind.os

# Check for:
# - Strict-Transport-Security
# - X-Content-Type-Options
# - X-Frame-Options
# - X-XSS-Protection
# - Referrer-Policy
```

---

## ROLLBACK PROCEDURES

### Step 1: Automatic Rollback (Kubernetes)

```bash
# View rollout history
kubectl rollout history deployment/evalion-mind -n evalion

# Rollback to previous version
kubectl rollout undo deployment/evalion-mind -n evalion

# Rollback to specific version
kubectl rollout undo deployment/evalion-mind --to-revision=2 -n evalion
```

### Step 2: Manual Rollback (Docker)

```bash
# Stop current container
docker stop evalion-mind-prod

# Run previous version
docker run -d \
  --name evalion-mind-prod \
  --restart always \
  -p 3000:3000 \
  --env-file /opt/evalion-mind/.env.production \
  your-registry.azurecr.io/evalion-mind:1.0.23
```

### Step 3: Database Rollback

```bash
# Restore from backup if needed
psql postgresql://evalion_prod_user:password@prod-db.example.com/evalion_prod < backup_20250128_120000.sql
```

---

## POST-DEPLOYMENT VERIFICATION

### Step 1: Health Checks

- [ ] Application responding on production domain
- [ ] Database connected and healthy
- [ ] Redis cache working
- [ ] API endpoints returning correct responses
- [ ] Authentication flow working
- [ ] File uploads functional
- [ ] Email notifications sending
- [ ] WebSocket connections stable
- [ ] SSL certificate valid
- [ ] Performance metrics acceptable

### Step 2: Smoke Testing

```bash
# Test critical user flows
1. User registration
2. User login
3. Start interview session
4. Complete interview
5. View report
6. Logout

# Test admin functions
1. View ATS dashboard
2. Move candidate between stages
3. View analytics
4. Access billing
```

### Step 3: Performance Testing

```bash
# Load test with Apache Bench
ab -n 1000 -c 10 https://evalion-mind.os/

# Monitor:
# - Response times
# - Error rates
# - CPU/Memory usage
# - Database queries
```

### Step 4: Security Testing

```bash
# Run OWASP scan
# Check for:
# - SQL Injection
# - XSS vulnerabilities
# - CSRF attacks
# - Authentication bypass
# - Unauthorized access
```

---

## TROUBLESHOOTING

### Application Won't Start

```bash
# Check logs
docker logs evalion-mind-prod

# Check environment variables
docker exec evalion-mind-prod env | grep -E "DATABASE|REDIS|JWT"

# Check database connectivity
docker exec evalion-mind-prod npm run db:validate

# Check Redis connectivity
docker exec evalion-mind-prod redis-cli -h $REDIS_HOST ping
```

### Database Connection Failing

```bash
# Test connection directly
psql -h prod-db.example.com -U evalion_prod_user -d evalion_prod

# Check if database exists
psql -h prod-db.example.com -U postgres -c "\l"

# Verify user permissions
psql -h prod-db.example.com -U postgres \
  -c "GRANT ALL PRIVILEGES ON DATABASE evalion_prod TO evalion_prod_user;"
```

### High CPU/Memory Usage

```bash
# Find resource-intensive processes
top

# Check application metrics
curl http://localhost:3000/metrics

# Check database queries
psql $DATABASE_URL -c "SELECT query, calls FROM pg_stat_statements ORDER BY calls DESC LIMIT 10;"

# Analyze slow queries
EXPLAIN ANALYZE SELECT ... FROM ...;
```

### WebSocket Connections Failing

```bash
# Check WebSocket is enabled in Nginx
curl -i -N -H "Connection: Upgrade" -H "Upgrade: websocket" http://localhost:3000/ws

# Check for proxy issues in logs
tail -f /var/log/nginx/error.log

# Verify proxy_read_timeout is set to high value
grep proxy_read_timeout /etc/nginx/sites-enabled/evalion-mind
```

---

## MONITORING DASHBOARD

### Create Grafana Dashboard for:

1. **Application Health**
   - Error rate
   - Response time
   - Requests per second
   - Active users

2. **Infrastructure**
   - CPU usage
   - Memory usage
   - Disk usage
   - Network I/O

3. **Database**
   - Query count
   - Query latency
   - Connection pool
   - Replication lag

4. **Business Metrics**
   - Interviews completed
   - Candidates processed
   - Reports generated
   - Revenue

---

## INCIDENT RESPONSE PLAN

### When Something Goes Wrong:

1. **Alert Team** (Pagerduty/Slack)
2. **Assess Impact** (Business impact assessment)
3. **Investigate** (Check logs, metrics, errors)
4. **Mitigate** (Temporary fix or rollback)
5. **Communicate** (Update status page)
6. **Resolve** (Root cause fix)
7. **Postmortem** (Review and prevent future)

---

## CONTACTS & ESCALATION

```
Primary On-Call:      [Name] - [Phone] - [Email]
Secondary On-Call:    [Name] - [Phone] - [Email]
Manager:              [Name] - [Phone] - [Email]
Cloud Provider:       [Support Link]
Database Provider:    [Support Link]
```

---

## FINAL SIGN-OFF

- [ ] Infrastructure Lead Approval
- [ ] Security Team Approval
- [ ] Database Admin Approval
- [ ] Operations Lead Approval
- [ ] Product Manager Approval

**Deployed By:** _______________  
**Date:** _______________  
**Time:** _______________  
**Status:** ✓ SUCCESSFUL / ✗ FAILED

---

**Last Updated:** January 28, 2025  
**Next Review:** February 28, 2025
