/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// ============================================================================
// APP STATE & ROUTING
// ============================================================================

export type AppState = 
  | 'LANDING'
  | 'AUTH'
  | 'DASHBOARD'
  | 'IDLE'
  | 'VERIFICATION'
  | 'INTERVIEW'
  | 'ANALYSIS'
  | 'REPORT'
  | 'PROFILE'
  | 'ATS'
  | 'PLATFORM'
  | 'PRICING'
  | 'ENTERPRISE'
  | 'DOCS'
  | 'SOLUTIONS'
  | 'ABOUT'
  | 'CONTACT'
  | 'POLICY'
  | 'DEMO_SESSION'
  | 'DEPLOY_PAGE'
  | 'STATUS'
  | 'FRONTEND_ARCH'
  | 'BACKEND_ARCH'
  | 'AI_ENGINE_ARCH'
  | 'SECURITY_ARCH'
  | 'BILLING';

// ============================================================================
// USER & AUTHENTICATION
// ============================================================================

export type UserRole = 'CANDIDATE' | 'RECRUITER' | 'INTERVIEWER';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  companyName?: string;
  password?: string;
  biometricEnabled?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface AuthCredentials {
  email: string;
  password: string;
}

export interface AuthResponse {
  user: User;
  token: string;
  refreshToken?: string;
  expiresIn: number;
}

// ============================================================================
// NOTIFICATIONS & UI
// ============================================================================

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
  recoveryHint?: string;
  duration?: number;
}

export type SocketStatus = 'CONNECTING' | 'CONNECTED' | 'UNSTABLE' | 'DISCONNECTED';

// ============================================================================
// INTERVIEW & QUESTIONS
// ============================================================================

export interface Question {
  id: number;
  text: string;
  category: 'BEHAVIORAL' | 'TECHNICAL' | 'SYSTEM_DESIGN' | 'CODE_CHALLENGE';
  durationSeconds: number;
  difficulty?: 'EASY' | 'MEDIUM' | 'HARD';
}

export interface InterviewContext {
  text: string;
  answer?: string;
  duration?: number;
  timestamp?: string;
}

export interface InterviewSession {
  id: string;
  candidateId: string;
  jobId: string;
  status: 'INITIATED' | 'IN_PROGRESS' | 'PAUSED' | 'COMPLETED' | 'CANCELLED';
  startedAt: string;
  completedAt?: string;
  transcript: string;
  context: InterviewContext[];
}

// ============================================================================
// PROCTORING & SECURITY
// ============================================================================

export type ProctorGazeStatus = 'FOCUSED' | 'DISTRACTED' | 'AWAY';
export type ExpressionType = 'NEUTRAL' | 'CONFIDENT' | 'UNCERTAIN' | 'STRESSED';
export type SystemIntegrity = 'SECURE' | 'WARNING' | 'COMPROMISED';

export interface ProctoringMetrics {
  gaze: ProctorGazeStatus;
  expression: ExpressionType;
  audioAnomaly: boolean;
  systemIntegrity: SystemIntegrity;
  timestamp?: string;
  suspiciousActivity?: string[];
}

export interface BiometricData {
  videoStream: Blob;
  audioStream: Blob;
  frameRate: number;
  resolution: string;
}

// ============================================================================
// REPORTS & ANALYSIS
// ============================================================================

export type HiringDecision = 'APPROVE' | 'REJECT' | 'REVIEW';

export interface EvaluationMetric {
  label: string;
  score: number;
  category: string;
}

export interface DetailedFeedback {
  summary: string;
  strengths: string[];
  improvements: string[];
  scores: {
    technicalAccuracy: number;
    communicationClarity: number;
    problemSolving: number;
  };
}

export interface QuestionResult {
  questionId: number;
  questionText: string;
  category: string;
  candidateAnswer: string;
  duration: number;
  score: number;
  detailedFeedback: DetailedFeedback;
}

export interface FinalReport {
  id: string;
  candidateId?: string;
  overallScore: number;
  metrics: EvaluationMetric[];
  questionResults: QuestionResult[];
  summary: string;
  hiringDecision: HiringDecision;
  generatedAt: string;
  aiInsights?: string;
}

// ============================================================================
// ATS & RECRUITMENT
// ============================================================================

export type ATSStageId = 's1' | 's2' | 's3' | 's4';

export interface ATSStage {
  id: ATSStageId;
  name: string;
  order: number;
  color: string;
}

export interface ATSJob {
  id: string;
  title: string;
  department: string;
  description?: string;
  recruiter: User;
  createdAt: string;
  status: 'OPEN' | 'CLOSED' | 'DRAFT';
}

export interface ParsedResumeData {
  skills: string[];
  experience: Array<{
    role: string;
    company: string;
    duration: string;
  }>;
  education: Array<{
    degree: string;
    institution: string;
  }>;
  summary?: string;
}

export interface ATSApplication {
  id: string;
  jobId: string;
  candidateName: string;
  candidateEmail: string;
  candidateAvatar: string;
  appliedDate: string;
  resumeText: string;
  stageId: ATSStageId;
  matchScore?: number;
  rankingReason?: string;
  parsedData?: ParsedResumeData;
  tags: string[];
  status: 'SCREENING' | 'INTERVIEW' | 'OFFER' | 'REJECTED' | 'HIRED';
}

// ============================================================================
// ERROR HANDLING
// ============================================================================

export interface AIKernelError extends Error {
  message: string;
  code?: string;
  recoveryHint?: string;
  statusCode?: number;
}

export class APIError implements AIKernelError {
  message: string;
  code?: string;
  recoveryHint?: string;
  statusCode?: number;
  name = 'APIError';

  constructor(message: string, statusCode?: number, recoveryHint?: string) {
    this.message = message;
    this.statusCode = statusCode;
    this.recoveryHint = recoveryHint;
  }
}

export class ValidationError implements AIKernelError {
  message: string;
  code = 'VALIDATION_ERROR';
  recoveryHint?: string;
  name = 'ValidationError';

  constructor(message: string, recoveryHint?: string) {
    this.message = message;
    this.recoveryHint = recoveryHint;
  }
}

// ============================================================================
// BILLING & SUBSCRIPTIONS
// ============================================================================

export type SubscriptionTier = 'SEED' | 'SCALE' | 'ENTERPRISE';

export interface Subscription {
  id: string;
  userId: string;
  tier: SubscriptionTier;
  status: 'ACTIVE' | 'PAUSED' | 'CANCELLED';
  createdAt: string;
  renewsAt: string;
  price: number;
  currency: string;
}

export interface UsageMetrics {
  concurrentInterviews: number;
  concurrentInterviewsLimit: number;
  aiProctorHours: number;
  aiProctorHoursLimit: number;
  adminSeats: number;
  adminSeatsLimit: number;
}

export interface Invoice {
  id: string;
  subscriptionId: string;
  amount: number;
  status: 'PAID' | 'PENDING' | 'FAILED' | 'REFUNDED';
  createdAt: string;
  dueDate: string;
  paidAt?: string;
}

// ============================================================================
// API REQUEST/RESPONSE TYPES
// ============================================================================

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}

export interface APIResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    message: string;
    code: string;
    details?: Record<string, any>;
  };
  timestamp: string;
}

// ============================================================================
// SOCKET EVENTS
// ============================================================================

export interface SocketMessage {
  type: string;
  payload: any;
  timestamp: string;
}

export interface PipelineUpdateEvent {
  jobId: string;
  applicationId: string;
  previousStage: ATSStageId;
  newStage: ATSStageId;
  timestamp: string;
}

export interface InterviewUpdateEvent {
  interviewId: string;
  status: 'STARTED' | 'PAUSED' | 'RESUMED' | 'COMPLETED';
  timestamp: string;
}

// ============================================================================
// COMPONENT PROPS
// ============================================================================

export interface DashboardProps {
  user: User;
  onNavigate: (state: AppState) => void;
}

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// ============================================================================
// UTILITY TYPES
// ============================================================================

export type Nullable<T> = T | null;
export type Optional<T> = T | undefined;
export type AsyncFunction<T> = () => Promise<T>;

export interface AsyncState<T> {
  data: Optional<T>;
  loading: boolean;
  error: Optional<Error>;
}

// ============================================================================
// FORM & VALIDATION
// ============================================================================

export interface FormField {
  name: string;
  label: string;
  type: 'text' | 'email' | 'password' | 'number' | 'textarea' | 'select';
  required: boolean;
  validation?: RegExp | ((value: any) => boolean);
  placeholder?: string;
  options?: Array<{ value: string; label: string }>;
}

export interface FormErrors {
  [fieldName: string]: string;
}

// ============================================================================
// DATABASE MODELS (for reference)
// ============================================================================

export interface UserDB {
  id: string;
  email: string;
  name: string;
  passwordHash: string;
  role: UserRole;
  companyName?: string;
  avatar?: string;
  biometricEnabled: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface InterviewDB {
  id: string;
  candidateId: string;
  jobId: string;
  transcript: string;
  status: string;
  startedAt: Date;
  completedAt?: Date;
  metadata: Record<string, any>;
}

export interface ReportDB {
  id: string;
  candidateId: string;
  overallScore: number;
  hiringDecision: HiringDecision;
  metrics: EvaluationMetric[];
  generatedAt: Date;
}

// ============================================================================
// EXPORT ALL TYPES
// ============================================================================

export * from './types';
